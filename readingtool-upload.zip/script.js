let startTime = 0;
let totalWordsRead = 0;
let usedPassages = [];
const assessmentData = {
    EASY: [
        {
            title: "A Peaceful Morning in the Park",
            text: "On a quiet morning, Lila walked to the small park near her home. The grass was still wet with dew, and the air smelled fresh and clean. She carried a book but decided to watch the birds instead. A bright yellow bird landed on a bench, chirping softly. Lila smiled and sat nearby, enjoying the peaceful moment. Soon, a gentle breeze moved the leaves, creating a calming sound. She felt relaxed and happy, grateful for the simple beauty around her. After a while, she opened her book and began to read quietly. The quiet park made her feel calm inside.",
            questions: [
                { q: "Why did Lila watch the birds instead of reading her book?", options: ["The book she had was not fun to read", "The time was too short to start reading", "The place was too noisy for her to read", "The Park felt more interesting than reading her book"], correct: 3 },
                { q: "What is the effect of the order of events in the passage?", options: ["It shows Lila quickly deciding to leave the park", "It shows Lila slowly becoming calm in the park", "It shows Lila slowly becoming bored in the park", "It shows Lila quickly becoming active in the park"], correct: 1 },
                { q: "What does the yellow bird represent in the passage?", options: ["It shows something new that surprises Lila", "It shows a sign that she should leave soon", "It shows a simple and beautiful part of nature", "It shows a small distraction from her reading"], correct: 2 },
                { q: "How would the mood change if the park were crowded and noisy?", options: ["It would feel the same as a quiet morning", "It would feel more active and fuller of people", "It would feel more exciting and fuller of noise", "It would feel less calm and more uncomfortable"], correct: 3 },
                { q: "How does Lila’s mental state change in the passage?", options: ["She becomes more worried about her situation", "She becomes more confused about what to do", "She becomes more active while staying outside", "She becomes more relaxed and calmer over time"], correct: 3 }
            ]
        },
        {
            title: "Cooking with Grandmother",
            text: "Marco loved helping his grandmother in the kitchen every afternoon. Together, they prepared simple meals that filled the house with warm, delicious smells. He learned how to chop vegetables carefully and stir soup slowly. His grandmother often told stories about her childhood while they cooked. Marco listened closely, laughing at her funny memories. One day, he surprised her by cooking a dish on his own. She tasted it and smiled proudly. Marco felt proud too, knowing he had learned something special. Cooking became their favorite way to spend time together and share love through food. They grew closer every day.",
            questions: [
                { q: "What was Marco doing every afternoon?", options: ["Games played in the home", "Watching programs on television", "Assisting his grandmother in cooking meals", "Going off by yourself to read books in silence"], correct: 2 },
                { q: "What did Marco learn to do in the kitchen?", options: ["How to run fast every day", "How to sing songs very loudly", "How to chop vegetables cautiously", "How to paint pictures in a beautiful way"], correct: 2 },
                { q: "What did Marco’s grandmother do when she was cooking?", options: ["Peacefully slept next to the table", "Shared stories from her childhood", "Used headphones to listen to music", "Related watched movies while cooking"], correct: 1 },
                { q: "How do you think Marco surprised his grandma?", options: ["Cooked a dish on his own", "Food purchased from the market", "The kitchen was cleaned very fast", "Presented her with flowers from his garden"], correct: 0 },
                { q: "What did Marco learn as he cooked?", options: ["Cooking is just for old folks", "People feel tired after cooking", "Time is too precious to waste on cooking", "If you cook, you can’t help but share love"], correct: 3 }
            ]
        },
        {
            title: "The River Adventure",
            text: "At the edge of the village, there was a small river that sparkled under the sun. Children often gathered there after school to play and cool their feet in the water. Nina liked to skip stones across the surface, counting how many times they bounced. Her friend Leo preferred building tiny boats from leaves and sticks. One afternoon, they decided to race their boats downstream. They cheered and ran along the riverbank, laughing loudly. In the end, both boats got stuck near the same rock, and they agreed it was a tie. They promised to return and play again tomorrow.",
            questions: [
                { q: "Where was the river located?", options: ["Behind the large school", "At the edge of the village", "At the center of the town", "Near the busy marketplace"], correct: 1 },
                { q: "What did Nina enjoy doing at the river?", options: ["Catch fish using a net", "Skip stones on the water", "Swim across the deep river", "Build tiny boats out of leaves"], correct: 1 },
                { q: "What did Leo enjoy doing?", options: ["Rushing down the path", "Sitting on the grass quietly", "Counting the stones carefully", "Building tiny boats out of leaves"], correct: 3 },
                { q: "What did they do during their boat race?", options: ["Nina was a very fast boat", "One boat sank in the water", "Leo’s boat reached the end", "Both boats became stuck together"], correct: 3 },
                { q: "What do Nina and Leo go on to decide in the end?", options: ["They needed bigger boats", "The river was too dangerous", "Benefits of withdrawing from there", "The race ended without a clear victor"], correct: 3 }
            ]
        },
        {
            title: "Watching the Sunset",
            text: "Every evening, Tomas sat by his window and watched the sky change colors. The bright blue slowly turned into shades of orange, pink, and purple. He liked to imagine stories about the clouds, seeing shapes like animals and castles. Sometimes, he wrote his ideas in a small notebook beside him. His younger sister would join him and point out her own shapes in the sky. They often laughed at their different ideas. As the stars began to appear, Tomas felt calm and inspired. Watching the sunset became his favorite way to relax and end his day peacefully.",
            questions: [
                { q: "How did Tomas watch the sunset?", options: ["From their house roof", "By his window at home", "Sitting in their backyard", "On a park bench near the flowing river"], correct: 1 },
                { q: "What change happened to the sky during sunset?", options: ["It changed from light to dark", "It went orange, pink, and purple", "It changed from blue to soft colors", "It gave way to mixed warm evening shades"], correct: 1 },
                { q: "What did Tomas enjoy doing while watching the clouds?", options: ["Making notes on his ideas", "Building out stories with cloud shapes", "Looking with one's eyes at the shapes in the sky", "Developing scenes from clouds and looking at them"], correct: 1 },
                { q: "Who accompanied Tomas during the sunset?", options: ["His close friend", "His older cousin", "His younger sister", "His next-door neighbor"], correct: 2 },
                { q: "How did Tomas feel at the end of the day?", options: ["Calm and peaceful", "Quiet and thoughtful", "Relaxed and inspired", "Pleased with, deeply full of joy"], correct: 2 }
            ]
        },
        {
            title: "The Old Attic Box",
            text: "Sara found a small, dusty box in the corner of her attic one weekend. Curious, she opened it and discovered old photographs and letters inside. Each picture showed people she did not recognize, smiling and posing together. She asked her mother about them and learned they were her great-grandparents and relatives from long ago.",
            questions: [
                { q: "Where did Sara find her little dusty box in the story?", options: ["Near the hallway door", "Beneath the table", "Far corner of her attic", "Hidden in a cabinet"], correct: 2 },
                { q: "When Sara opened the box, what did she find?", options: ["Old photographs and letters", "Toys and games", "Repair tools", "New garments"], correct: 0 },
                { q: "Who were the people she found in the photographs?", options: ["Neighbors", "Classmates", "Strangers", "Great-grandparents and relatives"], correct: 3 },
                { q: "What were Sara’s steps after discovering the photographs?", options: ["Asked her mother", "Showed friends", "Returned the box", "Kept them secret"], correct: 0 },
                { q: "What do we learn from Sara finding the box?", options: ["Family history influences identity", "Old things are always neat", "Young people don't care about family", "Discovery obscures the past"], correct: 0 }
            ]
        },
        {
            title: "Rainy Day Fort",
            text: "During a rainy afternoon, Ben stayed indoors and searched for something fun to do. He decided to build a small fort using blankets, chairs, and pillows. Carefully, he arranged everything to create a cozy space. Inside, he brought a flashlight and his favorite storybook. The sound of rain tapping on the roof made the moment even more relaxing. Ben imagined he was in a secret hideout, far away from everything. He spent hours reading and playing quietly. When the rain stopped, he stepped outside feeling happy, already planning to build a bigger fort next time.",
            questions: [
                { q: "What was the weather like when the story was set?", options: ["Rainy", "Sunny", "Windy", "Overcast"], correct: 0 },
                { q: "What did Ben decide to build?", options: ["Schoolwork", "A small fort", "Tidying room", "A new game"], correct: 1 },
                { q: "What did Ben use to make the fort?", options: ["Plastic containers", "Wood boards", "Blankets, chairs, pillows", "Cardboard boxes"], correct: 2 },
                { q: "How did Ben get into his fort?", options: ["Brought snacks", "Brought school supplies", "Brought a flashlight and book", "Brought toys and games"], correct: 2 },
                { q: "How did Ben feel after the rain ended?", options: ["Restless", "Worn out", "Dissatisfied", "Excited to build a bigger one"], correct: 3 }
            ]
        },
        {
            title: "Mia’s First Presentation",
            text: "In school, Mia was nervous about giving her first-class presentation. She practiced her speech many times at home, standing in front of a mirror. On the day of the presentation, her hands felt cold, and her heart beat fast. When it was her turn, she took a deep breath and began speaking slowly. As she continued, she became more confident. Her classmates listened quietly and smiled at her. When she finished, they clapped, and her teacher praised her effort. Mia felt proud of herself for facing her fear and doing her best in front of everyone.",
            questions: [
                { q: "What feelings did Mia have before her presentation?", options: ["Excited", "Indifferent", "Confident", "Nervous"], correct: 3 },
                { q: "How did Mia get her presentation ready?", options: ["Silent review", "Asked classmates", "Used videos", "Practiced in front of a mirror"], correct: 3 },
                { q: "When it was Mia’s turn, what did she do?", options: ["Paused and spoke slowly", "Postponed the turn", "Read passively", "Spoke fast"], correct: 0 },
                { q: "How did Mia’s classmates react?", options: ["Ignored her", "Interrupted her", "Listened and smiled", "Asked questions"], correct: 2 },
                { q: "What gave Mia pride when she finished?", options: ["Speed", "High score", "Zero mistakes", "Facing fear and determination"], correct: 3 }
            ]
        },
        {
            title: "Cleaning Day Discoveries",
            text: "One bright morning, Carlos decided to clean his room after weeks of putting it off. He started by picking up clothes and organizing his desk. As he worked, he found old toys and books he had forgotten about. Each item brought back happy memories from his childhood. Instead of throwing them away, he chose some to donate to others. After hours of cleaning, his room looked neat and fresh. Carlos felt a sense of accomplishment and peace. He promised himself to keep his space tidy and to help others by sharing things he no longer needed.",
            questions: [
                { q: "Why did Carlos decide to clean his room?", options: ["Family advice", "Routine task", "Looking for missing items", "Organizing after postponing"], correct: 3 },
                { q: "What did Carlos do first?", options: ["Picked up clothes and desk", "Reminisced", "Sorted old books", "Sorted donations"], correct: 0 },
                { q: "What did Carlos discover while cleaning?", options: ["Broken goods", "Large storage", "Items needing repair", "Significant childhood recollections"], correct: 3 },
                { q: "What did Carlos do with some items?", options: ["Trash them", "Donate them", "Keep in boxes", "Keep for later"], correct: 1 },
                { q: "How did Carlos feel after finishing?", options: ["Regretful", "Triumphant and at peace", "Interested in more cleaning", "Realized the challenge"], correct: 1 }
            ]
        },
        {
            title: "The Group Project",
            text: "In senior high school, students often work on group projects. One group was asked to prepare a report about the importance of reading. They divided the tasks: some researched, others wrote, and one member practiced reading the report aloud. During the presentation, the group performed well because everyone understood the material. Their teacher noted that strong reading skills helped them succeed.",
            questions: [
                { q: "What was the group project about?", options: ["Sports", "Music", "Science", "Reading"], correct: 3 },
                { q: "How did the group divide tasks?", options: ["One person worked", "Copied from book", "Same tasks", "Researched, wrote, read aloud"], correct: 3 },
                { q: "Why did the group perform well?", options: ["No teacher", "Skipped practice", "Memorized", "Understood material"], correct: 3 },
                { q: "What skill helped them succeed?", options: ["Singing", "Reading", "Drawing", "Dancing"], correct: 1 },
                { q: "Who noticed their success?", options: ["Principal", "Parents", "Teacher", "Classmate"], correct: 2 }
            ]
        },
        {
            title: "The Exam",
            text: "During an English exam, students were asked to read a passage and answer questions. Some students read quickly but misunderstood the text. Others read carefully and answered correctly. The teacher explained that accuracy and comprehension are more important than speed alone. Students realized that balanced reading skills lead to better academic performance.",
            questions: [
                { q: "What kind of exam was given?", options: ["Math", "History", "English", "Science"], correct: 2 },
                { q: "What happened to students who read quickly?", options: ["Wrote essay", "Skipped exam", "Answered correctly", "Misunderstood text"], correct: 3 },
                { q: "What did careful readers do?", options: ["Left room", "Finished early", "Failed test", "Answered correctly"], correct: 3 },
                { q: "What did the teacher emphasize?", options: ["Speed", "Writing", "Memorization", "Accuracy and comprehension"], correct: 3 },
                { q: "What did students realize?", options: ["Reading is boring", "Exams are useless", "Speed is everything", "Balanced skills improve performance"], correct: 3 }
            ]
        }
    ],
    MEDIUM: [
        {
            title: "The Unexpected Visitor",
            text: "On a quiet afternoon, Elena was studying when she heard a soft knock at the door. She opened it slowly and saw a small puppy standing outside, shivering and alone. Elena looked around but did not see anyone nearby. She brought the puppy inside and gave it food and water. The puppy quickly warmed up and began wagging its tail. Elena felt happy taking care of it. Later, she asked her neighbors if they had lost a puppy. Soon, the owner arrived and thanked her. Although she felt sad to say goodbye, she was glad she had helped the little animal safely return home.",
            questions: [
                { q: "Primary reason Elena brought the puppy inside?", options: ["Noise", "Wished to keep it", "Give to neighbor", "Worry about its condition"], correct: 3 },
                { q: "Detail suggesting puppy felt safe?", options: ["Feeding it", "Leaving it outside", "Ignoring it", "Wagging its tail"], correct: 3 },
                { q: "What can be inferred about Elena?", options: ["Indecisive student", "Knows all neighbors", "Caring/helpful nature", "Attached to animals"], correct: 2 },
                { q: "Why ask neighbors about the puppy?", options: ["Couldn't find owner", "Attachment", "Wanted praise", "Tired of care"], correct: 0 },
                { q: "Central theme?", options: ["Care and attention", "Communities", "Small acts of responsibility", "Tough calls"], correct: 2 }
            ]
        },
        {
            title: "A Lesson in Responsibility",
            text: "Kevin received a plant from his teacher to learn responsibility. Initially, he watered it daily. Over time, he became busy and forgot. He noticed leaves turning yellow and dry. He felt worried and realized his mistake. From then on, he cared for it properly and it grew healthy again. He learned responsibility requires consistency and patience.",
            questions: [
                { q: "Why did teacher give Kevin a plant?", options: ["Home décor", "Gardening interest", "Practice caring/responsibility", "Classroom prize"], correct: 2 },
                { q: "What made the plant unhealthy?", options: ["Poor light", "Irregular watering", "Wrong container", "Outdoor conditions"], correct: 1 },
                { q: "How did Kevin react to the dry plant?", options: ["Accepted issue", "Delegated care", "Managed properly again", "Replaced it"], correct: 2 },
                { q: "Synonym for 'consistency' in text?", options: ["Time management", "Following rules", "Regular intervals", "Easy completion"], correct: 2 },
                { q: "Ultimate lesson?", options: ["Avoid mistakes", "Vital teachers", "Specific knowledge", "Consistent work and care"], correct: 3 }
            ]
        },
        {
            title: "The School Project Challenge",
            text: "Anna’s group had to create an environmental poster. Initially, they disagreed on ideas, causing delays. After discussing calmly, they divided tasks and combined ideas. The teacher praised their teamwork and creativity. Anna realized working together with different opinions leads to success.",
            questions: [
                { q: "Initial problem?", options: ["No time", "Different ideas", "Lack of effort", "Missing materials"], correct: 1 },
                { q: "How was conflict resolved?", options: ["Strict rule", "Single leader", "Ignored disagreement", "Divided tasks and combined ideas"], correct: 3 },
                { q: "Teamwork outcome?", options: ["Solo is better", "Collaboration is superior", "Planning not needed", "Conflict prevents work"], correct: 1 },
                { q: "Why praise from teacher?", options: ["No discussion", "Independency", "Cooperation despite differences", "Ignoring leader"], correct: 2 },
                { q: "Main idea?", options: ["Teams equal quality", "Innefective results", "Individual initiative", "Clear instructions"], correct: 0 }
            ]
        },
        {
            title: "The Power of Practice",
            text: "Jason wanted to improve basketball skills. He struggled at first, missing shots. He watched videos and asked his coach for advice. Slowly, his aim improved. One day, he scored the winning shot. He learned consistent practice and determination achieve goals.",
            questions: [
                { q: "Challenge at beginning?", options: ["Lack of interest", "Struggling performance", "Teammate pressure", "No chance to play"], correct: 1 },
                { q: "How to improve?", options: ["Avoid hard training", "Just watch", "Consistent practice and advice", "No preparation"], correct: 2 },
                { q: "What does success demonstrate?", options: ["No guidance needed", "Innate talent", "Continuous practice results", "Quick results"], correct: 2 },
                { q: "Winning shot significance?", options: ["Proof of hard work", "Teammates ignored him", "Against rivals", "Berated for performance"], correct: 0 },
                { q: "Central message?", options: ["Talent > Practice", "Sports competition", "Natural ability", "Dedication leads to skills"], correct: 3 }
            ]
        },
        {
            title: "A Visit to the Library",
            text: "Lena visited the library for research. The quiet atmosphere helped her focus. Librarian assisted with resources. Lena discovered new facts and realized the value of libraries. She left feeling knowledgeable and inspired.",
            questions: [
                { q: "Why visit?", options: ["Meet friends", "Return books", "Research assignment", "Play games"], correct: 2 },
                { q: "Impact of atmosphere?", options: ["Distracted", "Bored", "Left early", "Concentration"], correct: 3 },
                { q: "Librarian's role?", options: ["Overlooked her", "Asked to leave", "Organizing only", "Assisted with resources"], correct: 3 },
                { q: "Realization?", options: ["Research is tiring", "Studying unimportant", "Libraries essential for learning", "Books are hard"], correct: 2 },
                { q: "Main takeaway?", options: ["Daily chore", "Research challenge", "Home study better", "Libraries support growth"], correct: 3 }
            ]
        },
        {
            title: "The Missing Homework",
            text: "Daniel forgot his homework. He felt nervous when asked to submit it. He realized he left it on his desk at home. Teacher allowed submission the next day. Daniel promised to be more organized. Taught him responsibility and checking belongings.",
            questions: [
                { q: "Why anxious?", options: ["Lost bag", "No studying", "Late", "Forgot homework"], correct: 3 },
                { q: "Daniel's realization?", options: ["Friend has it", "In locker", "Submitted early", "Left on desk at home"], correct: 3 },
                { q: "Teacher's reaction?", options: ["Lower grade", "Redo", "Overlooked it", "Submit next day"], correct: 3 },
                { q: "Lesson learned?", options: ["Ask for help", "Indifferent", "Organized and disciplined", "Home learning"], correct: 2 },
                { q: "Main message?", options: ["Strict rules", "Rules are tough", "Struggle for students", "Responsibility is key"], correct: 3 }
            ]
        },
        {
            title: "A Surprise Achievement",
            text: "Maya thought she was bad at drawing. Teacher encouraged practice. She drew sketches daily and improved. Her artwork was exhibit-chosen. She learned talent grows through effort and believing in oneself is key to success.",
            questions: [
                { q: "Initial view of talent?", options: ["Lacking skills", "Favorite subject", "Quite good", "Navigate life"], correct: 0 },
                { q: "Transformation cause?", options: ["Friend challenges", "Parents discouraged", "Teacher encouraged", "Competitions"], correct: 2 },
                { q: "Accomplishment?", options: ["Overlooked", "Showcased artwork", "Lost work", "Exhibit selection"], correct: 3 },
                { q: "Lesson on talent?", options: ["Effort required", "Irrelevant", "Fixed trait", "Flourishes through hard work"], correct: 3 },
                { q: "Main takeaway?", options: ["Challenging pursuit", "Faith in yourself", "Organizing exhibits", "More art activities"], correct: 1 }
            ]
        },
        {
            title: "The Friendly Competition",
            text: "Leo and Mark had a running competition. Leo led, Mark caught up. They crossed the finish line at the same time. Both felt energized. Competition helped them stay active and enjoy friendship.",
            questions: [
                { q: "Shared intention?", options: ["Pro race", "Who is fastest", "School event", "Activity and interaction"], correct: 3 },
                { q: "During race?", options: ["Finished in time", "Leo stopped", "Strong start vs catching up", "Did not finish"], correct: 2 },
                { q: "Behavior after?", options: ["Argued", "Complained", "Ignored each other", "Joked and complimented"], correct: 3 },
                { q: "Implication of 'friendly'?", options: ["Intense", "Assessed by teacher", "Official guidelines", "No hard feelings"], correct: 3 },
                { q: "Central theme?", options: ["Running is best", "Winning is goal", "Need clear winners", "Friendship via activities"], correct: 3 }
            ]
        },
        {
            title: "The Library Visit (Academic)",
            text: "Grade 12 students used the library for research. Read journals and articles. Some struggled with vocabulary; others summarized. Librarian noted comprehension is essential for learning. Reading proficiency supports academic success.",
            questions: [
                { q: "Why visit?", options: ["Games", "Friends", "Novels only", "Prepare for research"], correct: 3 },
                { q: "Materials read?", options: ["Comics", "Magazines", "Newspapers", "Journals, books, articles"], correct: 3 },
                { q: "Problem faced?", options: ["No teacher", "No time", "Broken computers", "Technical vocabulary"], correct: 3 },
                { q: "Helpful strategies?", options: ["Sleeping", "Ignoring", "Copying", "Summarizing and note-taking"], correct: 3 },
                { q: "Librarian's reminder?", options: ["Writing is useful", "Reading unnecessary", "Speed is most important", "Comprehension is essential"], correct: 3 }
            ]
        },
        {
            title: "The ABM Strand",
            text: "ABM students read business reports. Requires careful analysis. Class interpreted financial statements. Strong readers explained clearly. Strugglers focused only on numbers. Reading proficiency is vital in business studies.",
            questions: [
                { q: "Strand described?", options: ["Arts", "ABM", "STEM", "HUMSS"], correct: 1 },
                { q: "Texts read?", options: ["Novels", "Poems", "Comics", "Case studies and reports"], correct: 3 },
                { q: "Task given?", options: ["Draw chart", "Write poem", "Formulas", "Interpret financial statement"], correct: 3 },
                { q: "Who succeeded?", options: ["Skipped class", "Copied", "Ignored text", "Strong reading skills"], correct: 3 },
                { q: "Teacher's highlight?", options: ["Numbers enough", "Memorization", "Writing unnecessary", "Reading proficiency is vital"], correct: 3 }
            ]
        }
    ],
    HARD: [
        {
            title: "The Archivist’s Dilemma",
            text: "Elias preserved forgotten histories in a dimly lit archive. He found an anomalous document contradicting official records of a celebrated event. The official account seemed curated to hide uncomfortable truths. Elias feared revealing it would destabilize the institution. He felt torn between integrity and institutional loyalty.",
            questions: [
                { q: "Central conflict for Elias?", options: ["Reasoning for document", "Store or trash records", "Research vs duties", "Truth vs institutional loyalty"], correct: 3 },
                { q: "Implication of 'anomalous document'?", options: ["Accurate records", "Unfinished wear", "Manipulation to hide truths", "Fictional elements"], correct: 2 },
                { q: "What does hesitation suggest?", options: ["Fear of action", "Ethical dilemma of duty", "Lack of evidence", "Doubt of authenticity"], correct: 1 },
                { q: "Consequence of revealing?", options: ["Research advocacy", "Elevated standing", "Challenge authority/beliefs", "Public confidence"], correct: 2 },
                { q: "Broader theme?", options: ["Archival protection", "Personal career", "Preserving artifacts", "Truth vs consequences"], correct: 3 }
            ]
        },
        {
            title: "The Weight of Ambition (Adrian)",
            text: "Adrian climbed the corporate hierarchy with relentless ambition. He prioritized success over personal connections. As influence expanded, so did his isolation. Colleagues became subordinates. He reached the top but felt hollow, realizing he forfeited genuine fulfillment for accolades.",
            questions: [
                { q: "Main conflict (narrative error in doc, context Adrian)?", options: ["Tradition vs modern", "Truth vs loyalty", "Read vs write", "Ambition vs fulfillment"], correct: 3 },
                { q: "Corporate climb result?", options: ["More friends", "Transaction-based relations", "Better life balance", "Higher integrity"], correct: 1 },
                { q: "Paradox of achievement?", options: ["More money, more problems", "Success leads to isolation", "Desired everything but lost essence", "Skills equal accolades"], correct: 2 },
                { q: "Adrian's prioritization?", options: ["Success over connections", "Integrity over power", "Mentorship over metrics", "Family over corporate"], correct: 0 },
                { q: "Message?", options: ["Climb the ladder", "Ambition is vital", "Cost of relentless ambition", "Isolation is power"], correct: 2 }
            ]
        },
        {
            title: "The Silent Transformation",
            text: "Lena returned home after years, expecting familiarity. Instead, she saw streets modernized and faces replaced. Time had rewritten the place's identity. She realized change reshaped the town and her perception. Past existed only as reconstructed memory, vulnerable to distortion.",
            questions: [
                { q: "Insight gained?", options: ["Familiarity remains", "Change is physical only", "Memories shaped by time perception", "Fixed identity"], correct: 2 },
                { q: "Why feel alienated?", options: ["New environment perspective", "No people she knew", "Foreign practices", "Unrecognized locations"], correct: 0 },
                { q: "Implication about memory?", options: ["Unchanged", "Inevitable", "Historically accurate", "Reconstructive and distorted"], correct: 3 },
                { q: "Tone?", options: ["Hopeful", "Neutral", "Nostalgic/Uneasy", "Critical"], correct: 2 },
                { q: "Main theme?", options: ["Belonging via familiarity", "Certainty in past", "Time preserves all", "Change affects places and perception"], correct: 3 }
            ]
        },
        {
            title: "The Experiment of Consequences",
            text: "Dr. Varga conducted experiments challenging boundaries. In one study, a variable yielded unexpected results. Outcomes seemed benign but alarming consequences manifested. Despite warnings, he persisted. Realized his pursuit of knowledge precipitated uncontrollable outcomes.",
            questions: [
                { q: "Motivator for Dr. Varga?", options: ["Limited scope", "Past judgment", "Risk prevention", "Ignoring warnings for curiosity"], correct: 3 },
                { q: "Shift in outcomes?", options: ["Inadequate gear", "No records", "Insufficient data", "Unintended consequences"], correct: 3 },
                { q: "What do anomalies suggest?", options: ["Predictability", "Avoid all risks", "Discovery = success", "Curiosity can lead to unpleasantness"], correct: 3 },
                { q: "Reason for persistence?", options: ["Immediate halt", "Cautious adjustment", "Consultation", "Recognized hazards but continued"], correct: 3 },
                { q: "Central idea/Tone?", options: ["Excited possibilities", "Neutral results", "Optimistic", "Tense and cautionary"], correct: 3 }
            ]
        },
        {
            title: "The Echoes of Memory (Nathan)",
            text: "Nathan read an old journal. Past self seemed more confident. Discrepancies emerged between memory and record. Questioned reliability of recollections. Memory is a dynamic reconstruction susceptible to distortion.",
            questions: [
                { q: "Inner conflict?", options: ["Forgetting past", "Comparing successes", "Recorded clarity", "Questioning authenticity of memory"], correct: 3 },
                { q: "What does journal reveal?", options: ["Consistency", "Clarity", "Accuracy", "Difference between memory and record"], correct: 3 },
                { q: "Message about memory?", options: ["Fixed", "Reflects reality", "Depends on records", "Flexible/reconstructed"], correct: 3 },
                { q: "Feeling while reading?", options: ["Unaware", "Satisfied", "Uncertain about narrative", "Confident"], correct: 2 },
                { q: "Main theme?", options: ["Past shapes identity", "Memory is elusive/uncertain", "Reflection = growth", "Journals are accurate history"], correct: 1 }
            ]
        },
        {
            title: "The Collapse of Certainty (Victor)",
            text: "Victor relied on logic for control. Faced with a decision defying calculation, his framework failed. Methods were ineffective. Cognitive dissonance occurred, realizing not all life can be quantified. Certainty dissolved into ambiguity.",
            questions: [
                { q: "Initial belief system?", options: ["Unpredictability", "Every problem has logical solution", "Intuition", "Emotional choices"], correct: 1 },
                { q: "What challenges this?", options: ["Insufficient info", "Decision defying logic", "Multiple correct answers", "Emotional experience"], correct: 1 },
                { q: "Realization?", options: ["Logic is best", "Immediate solutions", "No uncertainty", "Not everything is logical"], correct: 3 },
                { q: "Theme?", options: ["Rational decision-making", "Complete understanding", "Straightforward solutions", "Certainty is limited in complexity"], correct: 3 },
                { q: "Tone?", options: ["Hopeful", "Neutral", "Confident", "Reflective and uncertain"], correct: 3 }
            ]
        },
        {
            title: "The Price of Understanding (Elise)",
            text: "Elise sought knowledge curiously. Uncovered ideas challenged beliefs. Realized limited previous understanding. Enlightenment cost certainty, replaced by complexity. Knowledge is a burden demanding questioning.",
            questions: [
                { q: "Drive for knowledge?", options: ["Recognition", "Academic success", "Intellectual capability", "Relentless curiosity"], correct: 3 },
                { q: "Effect of gaining knowledge?", options: ["Simplification", "Clear answers", "Boosts beliefs", "Sensitivity to complexity"], correct: 3 },
                { q: "Meaning of knowledge as a burden?", options: ["Limits access", "Prevents understanding", "Diminishes curiosity", "Acknowledging uncertainty"], correct: 3 },
                { q: "Theme?", options: ["Consistency", "Personal success", "Lack creates confusion", "Enlightenment and uncertainty"], correct: 3 },
                { q: "Tone?", options: ["Neutral", "Critical", "Enthusiastic", "Reflective/contemplative"], correct: 3 }
            ]
        },
        {
            title: "The Dichotomy of Progress",
            text: "Society glorifies progress as innovation/efficiency. Rapid pursuit creates unintended consequences like environmental degradation. Progress facilitates evolution but creates ethical dilemmas. Sustainability vs advancement.",
            questions: [
                { q: "Contradiction evident?", options: ["Solves social issues", "Quality improves", "Expansion emphasized", "Benefits and drawbacks"], correct: 3 },
                { q: "Associated problems?", options: ["Economic growth", "Production efficiency", "Tech advancement", "Degradation and inequality"], correct: 3 },
                { q: "Challenge introduced?", options: ["Speeding innovation", "Economic opportunities", "Accelerating tech", "Balance progress/sustainability"], correct: 3 },
                { q: "Central theme?", options: ["Positive results", "Erases differences", "Better society", "Complex ethical considerations"], correct: 3 },
                { q: "Tone?", options: ["Encouraging", "Optimistic", "Neutral", "Analytical and skeptical"], correct: 3 }
            ]
        },
        {
            title: "The STEM Challenge (Academic)",
            text: "STEM students read climate change articles with technical data. Comprehending readers explained real-world relations. Surface readers missed deeper meaning. Advanced reading is necessary for STEM success.",
            questions: [
                { q: "Article topic?", options: ["Poems", "History", "Climate change", "Business"], correct: 2 },
                { q: "Text content?", options: ["Songs", "Comics", "Pictures only", "Graphs, data, terms"], correct: 3 },
                { q: "Who explained findings?", options: ["Copiers", "Skippers", "Ignorers", "Strong comprehension"], correct: 3 },
                { q: "What did others miss?", options: ["Titles", "Pictures", "Easy words", "Deeper meaning"], correct: 3 },
                { q: "Teacher's conclusion?", options: ["Speed enough", "Memorization", "No reading needed", "Advanced reading skills necessary"], correct: 3 }
            ]
        },
        {
            title: "The Research Defense (Thesis)",
            text: "Grade 12 students prepared thesis defense. Read related studies and synthesized. Proficient readers answered panel with confidence. Strugglers found defending conclusions difficult. Advanced reading essential for academic success.",
            questions: [
                { q: "Event preparing for?", options: ["Field trip", "Quiz bee", "Thesis defense", "Sports"], correct: 2 },
                { q: "Reading material?", options: ["Novels", "Comics", "Magazines", "Related studies and literature"], correct: 3 },
                { q: "Who answered with confidence?", options: ["Copiers", "Memorizers", "Skippers", "Strong reading proficiency"], correct: 3 },
                { q: "Difficulty for strugglers?", options: ["Singing", "Charts", "Writing names", "Explaining research"], correct: 3 },
                { q: "Panel emphasis?", options: ["Speed", "Memorization", "Unnecessary", "Advanced reading skills essential"], correct: 3 }
            ]
        }
    ]

};

// 2. VARIABLES FOR TRACKING
let recognition;
let currentWordIndex = 0;
let wordElements = [];
let normalizedPassageWords = [];
let hesitationSeconds = 0;
let hesitationInterval;
let stopwatchSeconds = 0;
let stopwatchInterval;
let liveTranscriptCursor = "";
let liveResultSegments = new Map();
let mediaRecorder = null;
let mediaStream = null;
let recordedAudioChunks = [];
let recordedAudioMimeType = "audio/webm";
let isRecording = false;
let currentPassageData = null;
let pendingDomUpdates = [];
let domFlushHandle = null;
let lastHighlightedIndex = -1;
let audioContext = null;
let audioAnalyser = null;
let audioDataArray = null;
let noiseMonitorInterval = null;
let lastNoiseAdvanceAt = 0;
let pendingSpeechQueue = [];
let speechQueueHandle = null;
let sentenceRanges = [];
let activeSentenceIndex = 0;
let lastSpeechAssistAdvanceAt = 0;
let lastSpeechAssistTranscript = "";
let lastRecognitionEventAt = 0;
let shouldAutoRestartRecognition = false;
let recognitionRestartHandle = null;
let recognitionWatchdogHandle = null;
let lastRecognitionRestartAt = 0;
let recognitionSessionStartedAt = 0;
let recognitionNoEventRestartCount = 0;
let hasShownLiveHighlightFallbackNotice = false;
let lastBackendSttError = "";
let examStarted = false;
let shouldFocusComprehensionCtaAfterAlert = false;
let comprehensionCtaClearHandle = null;

// 3. CORE FUNCTIONS

// Splits the story into clickable/trackable words
function preparePassageForFluency(text) {
    const container = document.getElementById("passageText");
    const words = text.split(/\s+/);
    container.innerHTML = ""; 
    wordElements = [];
    normalizedPassageWords = [];
    currentWordIndex = 0;
    lastHighlightedIndex = -1;
    liveTranscriptCursor = "";
    liveResultSegments.clear();
    pendingSpeechQueue = [];
    speechQueueHandle = null;
    sentenceRanges = buildSentenceRanges(words);
    activeSentenceIndex = 0;

    words.forEach((word, index) => {
        const span = document.createElement("span");
        span.innerText = word + " "; // 👈 keeps spacing natural
        span.classList.add("word");
        span.id = `word-${index}`;
        container.appendChild(span);
        wordElements.push(span);
        normalizedPassageWords.push(normalizeWord(word));
    });

    // highlight first word
    highlightCurrentWord();
}

function buildSentenceRanges(rawWords) {
    const ranges = [];
    let sentenceStart = 0;

    for (let index = 0; index < rawWords.length; index++) {
        const rawWord = rawWords[index] || "";
        if (/[.!?]["')\]]*$/.test(rawWord)) {
            ranges.push({ start: sentenceStart, end: index });
            sentenceStart = index + 1;
        }
    }

    if (sentenceStart < rawWords.length) {
        ranges.push({ start: sentenceStart, end: rawWords.length - 1 });
    }

    if (!ranges.length && rawWords.length) {
        ranges.push({ start: 0, end: rawWords.length - 1 });
    }

    return ranges;
}

function flushDomUpdates() {
    if (!pendingDomUpdates.length) {
        domFlushHandle = null;
        return;
    }

    const updates = pendingDomUpdates;
    pendingDomUpdates = [];
    domFlushHandle = null;

    updates.forEach((fn) => fn());
}

function scheduleDomUpdate(fn) {
    pendingDomUpdates.push(fn);
    if (domFlushHandle) return;
    const raf = window.requestAnimationFrame || ((cb) => setTimeout(cb, 16));
    domFlushHandle = raf(flushDomUpdates);
}

function highlightCurrentWord() {
    const nextIndex = currentWordIndex;
    if (nextIndex === lastHighlightedIndex) return;

    scheduleDomUpdate(() => {
        if (wordElements[lastHighlightedIndex]) {
            wordElements[lastHighlightedIndex].classList.remove("current-word");
        }
        if (wordElements[nextIndex]) {
            wordElements[nextIndex].classList.add("current-word");
        }
    });

    lastHighlightedIndex = nextIndex;
}

function getTargetWordAt(index) {
    return normalizedPassageWords[index] || normalizeWord(wordElements[index]?.innerText);
}

function getCurrentSentenceRange() {
    if (!sentenceRanges.length) {
        return { start: 0, end: Math.max(wordElements.length - 1, 0) };
    }

    return sentenceRanges[activeSentenceIndex] || sentenceRanges[sentenceRanges.length - 1];
}

function syncSentencePointerToCurrentWord() {
    while (
        activeSentenceIndex < sentenceRanges.length - 1 &&
        currentWordIndex > sentenceRanges[activeSentenceIndex].end
    ) {
        activeSentenceIndex++;
    }
}

function findLookaheadMatch(spokenWord, startIndex, maxLookahead = FAST_READING_LOOKAHEAD, hardEndIndex = wordElements.length - 1) {
    if (!spokenWord) return -1;

    const endIndex = Math.min(wordElements.length - 1, startIndex + maxLookahead, hardEndIndex);
    for (let index = startIndex; index <= endIndex; index++) {
        if (isAcceptableWordMatch(spokenWord, getTargetWordAt(index))) {
            return index;
        }
    }

    return -1;
}

function getWordSimilarity(wordA, wordB) {
    if (!wordA || !wordB) return 0;
    if (isAcceptableWordMatch(wordA, wordB)) return 1;

    const distance = levenshteinDistance(wordA, wordB);
    const baseLength = Math.max(wordA.length, wordB.length, 1);
    return 1 - distance / baseLength;
}

function applyFinalSentenceFallback(spokenWords, confidence = 1, maxAllowedIndex = wordElements.length - 1) {
    if (!spokenWords.length || currentWordIndex >= wordElements.length) {
        return false;
    }

    syncSentencePointerToCurrentWord();
    const sentence = getCurrentSentenceRange();
    const sentenceStart = Math.max(currentWordIndex, sentence.start);
    const sentenceEnd = Math.min(sentence.end, wordElements.length - 1, maxAllowedIndex);

    if (sentenceStart > sentenceEnd) {
        return false;
    }

    let spokenCursor = 0;
    let matchedCount = 0;
    const perWordActions = [];

    for (let targetIndex = sentenceStart; targetIndex <= sentenceEnd; targetIndex++) {
        const targetWord = getTargetWordAt(targetIndex);
        let matchAt = -1;
        let bestSimilarity = 0;
        const searchLimit = Math.min(spokenWords.length - 1, spokenCursor + 4);

        for (let probe = spokenCursor; probe <= searchLimit; probe++) {
            const probeWord = normalizeWord(spokenWords[probe]);
            if (!probeWord) continue;

            const similarity = getWordSimilarity(probeWord, targetWord);
            if (similarity > bestSimilarity) {
                bestSimilarity = similarity;
                matchAt = probe;
            }

            if (similarity >= 0.999) {
                break;
            }
        }

        if (matchAt !== -1 && bestSimilarity >= 0.6) {
            matchedCount++;
            perWordActions.push({ type: bestSimilarity >= 0.8 ? "read" : "mis", index: targetIndex });
            spokenCursor = matchAt + 1;
        } else {
            perWordActions.push({ type: "omit", index: targetIndex });
        }
    }

    const sentenceWordCount = sentenceEnd - sentenceStart + 1;
    const matchRatio = matchedCount / Math.max(sentenceWordCount, 1);

    // Require moderate confidence that chunk corresponds to this sentence.
    if (matchedCount < 2 && sentenceWordCount >= 4) {
        return false;
    }
    if (matchRatio < 0.35 && confidence >= LOW_CONFIDENCE_MISPRONUNCIATION_THRESHOLD) {
        return false;
    }

    perWordActions.forEach((action) => {
        if (action.type === "read") {
            markWordAsRead(action.index);
            return;
        }
        if (action.type === "mis") {
            markWordAsError(action.index, "mis-error");
            return;
        }
        markWordAsError(action.index, "omit-error");
    });

    currentWordIndex = sentenceEnd + 1;
    syncSentencePointerToCurrentWord();
    highlightCurrentWord();
    resetHesitation();
    return true;
}

function enqueueSpeechWords(spokenText, options) {
    if (!spokenText) return;

    pendingSpeechQueue.push({ spokenText, options });
    if (speechQueueHandle) return;

    const raf = window.requestAnimationFrame || ((cb) => setTimeout(cb, 16));
    speechQueueHandle = raf(processSpeechQueue);
}

function processSpeechQueue() {
    speechQueueHandle = null;

    if (!isRecording || !pendingSpeechQueue.length) {
        pendingSpeechQueue = [];
        return;
    }

    const batchSize = 4;
    let processed = 0;

    while (pendingSpeechQueue.length && processed < batchSize && isRecording) {
        const item = pendingSpeechQueue.shift();
        handleVoiceInput(item.spokenText, item.options);
        processed++;
    }

    if (pendingSpeechQueue.length && isRecording) {
        const raf = window.requestAnimationFrame || ((cb) => setTimeout(cb, 16));
        speechQueueHandle = raf(processSpeechQueue);
    }
}

function flushPendingSpeechQueueImmediately() {
    while (pendingSpeechQueue.length) {
        const item = pendingSpeechQueue.shift();
        handleVoiceInput(item.spokenText, item.options);
    }

    speechQueueHandle = null;
}

function getPendingInterimTranscriptSnapshot() {
    if (!liveResultSegments.size) return "";

    const orderedSegments = Array.from(liveResultSegments.entries())
        .sort((a, b) => Number(a[0]) - Number(b[0]))
        .map(([, value]) => String(value || "").trim())
        .filter(Boolean);

    return orderedSegments.join(" ").trim();
}

function waitForRecognitionDrain(timeoutMs = 180) {
    return new Promise((resolve) => {
        setTimeout(resolve, Math.max(0, timeoutMs));
    });
}

function scheduleRecognitionRestart() {
    if (recognitionRestartHandle) {
        clearTimeout(recognitionRestartHandle);
        recognitionRestartHandle = null;
    }

    if (!recognition || !isRecording || !shouldAutoRestartRecognition) {
        return;
    }

    recognitionRestartHandle = setTimeout(() => {
        recognitionRestartHandle = null;

        if (!recognition || !isRecording || !shouldAutoRestartRecognition) {
            return;
        }

        lastRecognitionRestartAt = Date.now();

        try {
            recognition.start();
        } catch (error) {
            // Some mobile browsers throw if restart is too quick; retry once.
            recognitionRestartHandle = setTimeout(() => {
                recognitionRestartHandle = null;
                if (!recognition || !isRecording || !shouldAutoRestartRecognition) return;
                try {
                    recognition.start();
                } catch (retryError) {
                    console.warn("Recognition restart failed:", retryError);
                }
            }, 220);
        }
    }, 120);
}

function stopRecognitionWatchdog() {
    if (recognitionWatchdogHandle) {
        clearInterval(recognitionWatchdogHandle);
        recognitionWatchdogHandle = null;
    }
}

function startRecognitionWatchdog() {
    stopRecognitionWatchdog();

    if (!recognition) {
        return;
    }

    recognitionWatchdogHandle = setInterval(() => {
        if (!isRecording || !shouldAutoRestartRecognition || !recognition) {
            return;
        }

        const now = Date.now();
        const restartCooldownElapsed = now - lastRecognitionRestartAt > 1800;

        if (!lastRecognitionEventAt) {
            const initialSilenceTooLong = recognitionSessionStartedAt > 0 && now - recognitionSessionStartedAt > 3200;

            if (initialSilenceTooLong && restartCooldownElapsed) {
                recognitionNoEventRestartCount++;
                scheduleRecognitionRestart();

                if (recognitionNoEventRestartCount >= 3 && !hasShownLiveHighlightFallbackNotice) {
                    hasShownLiveHighlightFallbackNotice = true;
                    showAppAlert(
                        "Your device/browser has limited live speech events, so live highlights may pause. Continue reading and press Stop Recording to get final transcript-based scoring.",
                        "Limited Live Highlight"
                    );
                }
            }

            return;
        }

        const staleRecognitionStream = now - lastRecognitionEventAt > 2600;

        if (staleRecognitionStream && restartCooldownElapsed) {
            scheduleRecognitionRestart();
        }
    }, 700);
}

function handleInterimVoiceInput(spokenText) {
    if (currentWordIndex >= wordElements.length) return false;

    const spokenWords = spokenText
        .toLowerCase()
        .replace(/[^\w\s']/g, "")
        .split(/\s+/)
        .filter(Boolean);

    let advanced = false;

    for (let i = 0; i < spokenWords.length; i++) {
        if (currentWordIndex >= wordElements.length) {
            break;
        }

        const token = normalizeWord(spokenWords[i]);
        if (!token || token.length < INTERIM_MIN_TOKEN_LENGTH) {
            continue;
        }

        const targetWord = getTargetWordAt(currentWordIndex);
        if (!targetWord) {
            continue;
        }

        // Interim path is intentionally strict: only explicit current-word hits.
        if (isAcceptableWordMatch(token, targetWord)) {
            markWordAsRead(currentWordIndex);
            currentWordIndex++;
            advanced = true;
            resetHesitation();
        }
    }

    if (advanced) {
        syncSentencePointerToCurrentWord();
        highlightCurrentWord();

        if (currentWordIndex >= wordElements.length) {
            stopFluencyTest();
        }
    }

    return advanced;
}

function normalizeWord(value) {
    return (value || "")
        .toLowerCase()
        .replace(/[^a-z0-9']/g, "");
}

function normalizePhoneticBridge(value) {
    let token = normalizeWord(value);
    if (!token) return "";

    // Bridge common Filipino-accent approximations to improve English token matching.
    token = token
        .replace(/ph/g, "f")
        .replace(/ck/g, "k")
        .replace(/qu/g, "kw")
        .replace(/tion/g, "syon")
        .replace(/ci/g, "si")
        .replace(/ce/g, "se")
        .replace(/cy/g, "si")
        .replace(/v/g, "b")
        .replace(/z/g, "s")
        .replace(/x/g, "ks")
        .replace(/th/g, "t")
        .replace(/j/g, "dy")
        .replace(/c/g, "k")
        .replace(/oo/g, "u")
        .replace(/ee/g, "i")
        .replace(/ou/g, "aw")
        .replace(/([a-z])\1+/g, "$1");

    return token;
}

const ENGLISH_VARIANT_GROUPS = [
    ["color", "colour"],
    ["favorite", "favourite"],
    ["honor", "honour"],
    ["organize", "organise"],
    ["center", "centre"],
    ["meter", "metre"],
    ["liter", "litre"],
    ["theater", "theatre"],
    ["analyze", "analyse"],
    ["program", "programme"]
];

function isVariantEquivalent(wordA, wordB) {
    return ENGLISH_VARIANT_GROUPS.some(group => group.includes(wordA) && group.includes(wordB));
}

function isAcceptableWordMatch(spokenWord, targetWord) {
    if (!spokenWord || !targetWord) return false;
    if (spokenWord === targetWord) return true;
    if (isVariantEquivalent(spokenWord, targetWord)) return true;

    const bridgeSpoken = normalizePhoneticBridge(spokenWord);
    const bridgeTarget = normalizePhoneticBridge(targetWord);
    if (!bridgeSpoken || !bridgeTarget) return false;

    if (bridgeSpoken === bridgeTarget) return true;

    const bridgeDistance = levenshteinDistance(bridgeSpoken, bridgeTarget);
    const bridgeBaseLength = Math.max(bridgeSpoken.length, bridgeTarget.length, 1);
    const bridgeSimilarity = 1 - bridgeDistance / bridgeBaseLength;

    if (bridgeSimilarity >= 0.8) return true;

    return false;
}

const LOW_CONFIDENCE_MISPRONUNCIATION_THRESHOLD = 0.82;
const MISPRONUNCIATION_SIMILARITY_THRESHOLD = 0.4;
const AZURE_MISPRONUNCIATION_ACCURACY_THRESHOLD = 75;
const STRICT_RECOGNITION_MODE = true;
const STRICT_NOISE_FALLBACK_MODE = false;
const NOISE_RMS_THRESHOLD = 0.12;
const NOISE_ADVANCE_COOLDOWN_MS = 350;
const FAST_READING_LOOKAHEAD = 4;
const SPEECH_ASSIST_COOLDOWN_MS = 1200;
const SPEECH_ASSIST_MIN_CONFIDENCE = 0.5;
const INTERIM_PROCESS_MIN_CONFIDENCE = 0.45;
const FINAL_PROCESS_MIN_CONFIDENCE = 0.3;
const INTERIM_MIN_TOKEN_LENGTH = 2;
const USE_BACKEND_STT_MODE = true;
const BROWSER_RECOGNITION_LANG = "en-US";
const BACKEND_STT_LANGUAGE = "en";
const BACKEND_STT_MIN_TRANSCRIPT_CHARS = 2;
const BACKEND_STT_MIN_MATCHED_WORDS = 4;
const BACKEND_STT_MIN_MATCH_RATIO = 0.18;
const BACKEND_STT_ENDPOINTS = [
    "/.netlify/functions/stt-transcribe"
];
// Set to true only when Azure Speech credentials are configured in Netlify.
const ENABLE_AZURE_PRONUNCIATION_ASSESSMENT = false;
const AZURE_ASSESSMENT_ENDPOINTS = [
    "/.netlify/functions/azure-pronunciation-assessment"
];

function clearWordStateClasses(el) {
    if (!el) return;
    el.classList.remove("read-success", "sub-error", "omit-error", "add-error", "mis-error");
}

function advanceWordFromSpeechAssist(className = "sub-error") {
    if (!isRecording || currentWordIndex >= wordElements.length) return;

    markWordAsError(currentWordIndex, className);
    currentWordIndex++;
    syncSentencePointerToCurrentWord();
    highlightCurrentWord();
    resetHesitation();

    if (currentWordIndex >= wordElements.length) {
        stopFluencyTest();
    }
}

function maybeAssistProgressFromSpeech(result, transcript) {
    if (!isRecording || currentWordIndex >= wordElements.length) return;

    const normalizedTranscript = normalizeWord(transcript);
    if (!normalizedTranscript) return;

    const now = Date.now();
    const isFinalResult = result?.isFinal === true;
    const rawConfidence = result?.[0]?.confidence;
    const confidence = (typeof rawConfidence === "number" && rawConfidence > 0) ? rawConfidence : null;

    if (!isFinalResult) {
        return;
    }

    if (confidence !== null && confidence < SPEECH_ASSIST_MIN_CONFIDENCE) {
        return;
    }

    if (now - lastSpeechAssistAdvanceAt < SPEECH_ASSIST_COOLDOWN_MS) {
        return;
    }

    if (normalizedTranscript.length < 4) {
        return;
    }

    // Ignore repeated identical chunks often produced when user is silent.
    if (normalizedTranscript === lastSpeechAssistTranscript) {
        return;
    }

    advanceWordFromSpeechAssist("sub-error");
    lastSpeechAssistAdvanceAt = now;
    lastSpeechAssistTranscript = normalizedTranscript;
}

function showAppAlert(message, title = "Notice") {
    const alertRoot = document.getElementById("appAlert");
    const titleEl = document.getElementById("appAlertTitle");
    const messageEl = document.getElementById("appAlertMessage");

    if (!alertRoot || !titleEl || !messageEl) {
        window.alert(message);
        return;
    }

    titleEl.innerText = title;
    messageEl.innerText = message;
    alertRoot.classList.add("show");
    alertRoot.setAttribute("aria-hidden", "false");
}

function closeAppAlert() {
    const alertRoot = document.getElementById("appAlert");
    if (!alertRoot) return;

    alertRoot.classList.remove("show");
    alertRoot.setAttribute("aria-hidden", "true");

    if (shouldFocusComprehensionCtaAfterAlert) {
        shouldFocusComprehensionCtaAfterAlert = false;
        window.scrollTo({ top: 0, behavior: "smooth" });
        setTimeout(spotlightComprehensionButton, 420);
    }
}

window.closeAppAlert = closeAppAlert;

function spotlightComprehensionButton() {
    const ctaButton = document.getElementById("openComprehensionBtn");
    if (!ctaButton) return;

    ctaButton.classList.remove("cta-glow");
    // Force reflow so animation restarts every time after submit.
    void ctaButton.offsetWidth;
    ctaButton.classList.add("cta-glow");

    ctaButton.scrollIntoView({ behavior: "smooth", block: "center" });

    if (typeof ctaButton.focus === "function") {
        ctaButton.focus({ preventScroll: true });
    }

    if (comprehensionCtaClearHandle) {
        clearTimeout(comprehensionCtaClearHandle);
    }

    comprehensionCtaClearHandle = setTimeout(() => {
        ctaButton.classList.remove("cta-glow");
    }, 8000);
}

function hasWordStateClass(el, className) {
    return (
        className &&
        el.classList.contains(className) &&
        !el.classList.contains("current-word")
    );
}

function markWordAsRead(index) {
    const shouldCount = arguments[1] !== false;
    const el = wordElements[index];
    if (!el) return;

    if (hasWordStateClass(el, "read-success")) {
        if (shouldCount && el.dataset.readCounted !== "1") {
            totalWordsRead++;
            el.dataset.readCounted = "1";
        }
        return;
    }

    scheduleDomUpdate(() => {
        el.classList.remove("current-word");
        clearWordStateClasses(el);
        el.classList.add("read-success");
    });
    if (shouldCount) {
        if (el.dataset.readCounted !== "1") {
            totalWordsRead++;
            el.dataset.readCounted = "1";
        }
    } else {
        el.dataset.readCounted = "0";
    }
}

function markWordAsError(index, className) {
    const el = wordElements[index];
    if (!el) return;

    if (hasWordStateClass(el, className)) {
        return;
    }

    scheduleDomUpdate(() => {
        el.classList.remove("current-word");
        clearWordStateClasses(el);
        el.classList.add(className);
    });
}

function levenshteinDistance(a, b) {
    const rows = a.length + 1;
    const cols = b.length + 1;
    const dp = Array.from({ length: rows }, () => Array(cols).fill(0));

    for (let i = 0; i < rows; i++) dp[i][0] = i;
    for (let j = 0; j < cols; j++) dp[0][j] = j;

    for (let i = 1; i < rows; i++) {
        for (let j = 1; j < cols; j++) {
            const cost = a[i - 1] === b[j - 1] ? 0 : 1;
            dp[i][j] = Math.min(
                dp[i - 1][j] + 1,
                dp[i][j - 1] + 1,
                dp[i - 1][j - 1] + cost
            );
        }
    }

    return dp[a.length][b.length];
}

function formatStopwatch(totalSeconds) {
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function updateStopwatchDisplay() {
    document.getElementById("seconds").innerText = formatStopwatch(stopwatchSeconds);
}

function startStopwatch() {
    clearInterval(stopwatchInterval);
    stopwatchSeconds = 0;
    updateStopwatchDisplay();

    stopwatchInterval = setInterval(() => {
        stopwatchSeconds++;
        updateStopwatchDisplay();
    }, 1000);
}

async function startAudioRecording() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        return false;
    }

    recordedAudioChunks = [];

    const preferredMimeTypes = [
        "audio/webm;codecs=opus",
        "audio/ogg;codecs=opus",
        "audio/webm",
        "audio/ogg"
    ];

    const selectedMimeType = preferredMimeTypes.find(type => MediaRecorder.isTypeSupported(type));
    recordedAudioMimeType = selectedMimeType || "audio/webm";

    try {
        const audioConstraints = {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true
        };

        mediaStream = await navigator.mediaDevices.getUserMedia({
            audio: audioConstraints
        });

        mediaRecorder = selectedMimeType
            ? new MediaRecorder(mediaStream, { mimeType: selectedMimeType })
            : new MediaRecorder(mediaStream);

        mediaRecorder.ondataavailable = (event) => {
            if (event.data && event.data.size > 0) {
                recordedAudioChunks.push(event.data);
            }
        };

        mediaRecorder.start(250);
        startStrictNoiseMonitor();
        return true;
    } catch (error) {
        console.warn("Audio recording could not start:", error);
        mediaRecorder = null;
        if (mediaStream) {
            mediaStream.getTracks().forEach(track => track.stop());
            mediaStream = null;
        }
        stopStrictNoiseMonitor();
        return false;
    }
}

async function ensureMicrophonePermission() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        showAppAlert(
            "Microphone is not available in this browser/environment. Use HTTPS and a supported Chrome browser.",
            "Microphone Unavailable"
        );
        return false;
    }

    try {
        const probeStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        probeStream.getTracks().forEach((track) => track.stop());
        return true;
    } catch (error) {
        const reason = String(error?.name || "").toLowerCase();
        const blockedByPermission = reason.includes("notallowed") || reason.includes("security");

        showAppAlert(
            blockedByPermission
                ? "Microphone permission is blocked. Enable microphone access for this site in browser settings, then try again."
                : "Could not access your microphone. Check browser/site mic settings and device input, then try again.",
            "Microphone Access Needed"
        );

        return false;
    }
}

function startStrictNoiseMonitor() {
    stopStrictNoiseMonitor();

    if (!STRICT_RECOGNITION_MODE || !STRICT_NOISE_FALLBACK_MODE || !mediaStream) {
        return;
    }

    const AudioContextCtor = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextCtor) {
        return;
    }

    try {
        audioContext = new AudioContextCtor();
        const source = audioContext.createMediaStreamSource(mediaStream);
        audioAnalyser = audioContext.createAnalyser();
        audioAnalyser.fftSize = 1024;
        source.connect(audioAnalyser);
        audioDataArray = new Uint8Array(audioAnalyser.fftSize);

        noiseMonitorInterval = setInterval(() => {
            if (!isRecording || !audioAnalyser || !audioDataArray) return;

            audioAnalyser.getByteTimeDomainData(audioDataArray);

            let sumSquares = 0;
            for (let i = 0; i < audioDataArray.length; i++) {
                const centered = (audioDataArray[i] - 128) / 128;
                sumSquares += centered * centered;
            }

            const rms = Math.sqrt(sumSquares / audioDataArray.length);
            const now = Date.now();

            if (rms >= NOISE_RMS_THRESHOLD && now - lastNoiseAdvanceAt >= NOISE_ADVANCE_COOLDOWN_MS) {
                advanceWordFromStrictNoise();
                lastNoiseAdvanceAt = now;
            }
        }, 80);
    } catch (error) {
        console.warn("Strict noise monitor could not start:", error);
        stopStrictNoiseMonitor();
    }
}

function stopStrictNoiseMonitor() {
    if (noiseMonitorInterval) {
        clearInterval(noiseMonitorInterval);
        noiseMonitorInterval = null;
    }

    audioDataArray = null;
    audioAnalyser = null;

    if (audioContext) {
        audioContext.close().catch(() => {});
        audioContext = null;
    }
}

function advanceWordFromStrictNoise() {
    if (!isRecording || currentWordIndex >= wordElements.length) return;

    // Strict mode: any strong audio burst can advance the current token as addition/hit.
    markWordAsError(currentWordIndex, "add-error");
    currentWordIndex++;
    highlightCurrentWord();
    resetHesitation();

    if (currentWordIndex >= wordElements.length) {
        stopFluencyTest();
    }
}

function stopAudioRecordingAndGetBlob() {
    return new Promise((resolve) => {
        if (!mediaRecorder) {
            resolve(null);
            return;
        }

        const finalizeBlob = () => {
            const mimeType = recordedAudioMimeType || "audio/webm";
            const audioBlob = recordedAudioChunks.length
                ? new Blob(recordedAudioChunks, { type: mimeType })
                : null;

            recordedAudioChunks = [];

            if (mediaStream) {
                mediaStream.getTracks().forEach(track => track.stop());
            }

            mediaStream = null;
            mediaRecorder = null;
            stopStrictNoiseMonitor();

            resolve(audioBlob);
        };

        if (mediaRecorder.state === "inactive") {
            finalizeBlob();
            return;
        }

        mediaRecorder.onstop = finalizeBlob;
        mediaRecorder.stop();
    });
}

async function applyAzurePronunciationAssessment(audioBlob) {
    if (!ENABLE_AZURE_PRONUNCIATION_ASSESSMENT) {
        return false;
    }

    if (!audioBlob || !currentPassageData?.text) {
        return false;
    }

    const arrayBuffer = await audioBlob.arrayBuffer();
    const audioBase64 = arrayBufferToBase64(arrayBuffer);
    const requestPayload = {
        audioBase64,
        mimeType: recordedAudioMimeType || audioBlob.type || "audio/webm",
        referenceText: currentPassageData.text,
        language: "en-US"
    };

    for (const endpoint of AZURE_ASSESSMENT_ENDPOINTS) {
        try {
            const response = await fetch(endpoint, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(requestPayload)
            });

            if (!response.ok) {
                console.warn("Azure pronunciation assessment HTTP error", endpoint, response.status);
                continue;
            }

            const payload = await response.json();
            if (!payload?.ok || !Array.isArray(payload.words)) {
                console.warn("Azure pronunciation assessment payload invalid", endpoint, payload);
                continue;
            }

            applyAzureWordAssessment(payload.words);
            return true;
        } catch (error) {
            console.warn("Azure pronunciation assessment failed for endpoint:", endpoint, error);
        }
    }

    return false;
}

async function applyBackendSttTranscription(audioBlob, options = {}) {
    if (!USE_BACKEND_STT_MODE || !audioBlob || !currentPassageData?.text) {
        return false;
    }

    lastBackendSttError = "";

    const arrayBuffer = await audioBlob.arrayBuffer();
    const audioBase64 = arrayBufferToBase64(arrayBuffer);

    const requestPayload = {
        audioBase64,
        mimeType: recordedAudioMimeType || audioBlob.type || "audio/webm",
        language: BACKEND_STT_LANGUAGE,
        referenceText: currentPassageData.text,
        provider: "auto"
    };

    for (const endpoint of BACKEND_STT_ENDPOINTS) {
        try {
            const response = await fetch(endpoint, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(requestPayload)
            });

            if (!response.ok) {
                let details = "";
                try {
                    const errPayload = await response.json();
                    details = String(errPayload?.error || errPayload?.details || "").trim();
                } catch (err) {
                    try {
                        details = (await response.text()).trim();
                    } catch (errText) {
                        details = "";
                    }
                }
                lastBackendSttError = details || `HTTP ${response.status}`;
                continue;
            }

            const payload = await response.json();
            const transcript = String(payload?.transcript || "").trim();

            if (!payload?.ok || transcript.length < BACKEND_STT_MIN_TRANSCRIPT_CHARS) {
                lastBackendSttError = String(payload?.error || payload?.details || "Empty transcript from STT");
                continue;
            }

            const transcriptQuality = estimateTranscriptPassageQuality(transcript);
            if (
                transcriptQuality.matchedWords < BACKEND_STT_MIN_MATCHED_WORDS ||
                transcriptQuality.matchRatio < BACKEND_STT_MIN_MATCH_RATIO
            ) {
                lastBackendSttError = `Low transcript overlap (${transcriptQuality.matchedWords}/${transcriptQuality.totalWords})`;
                continue;
            }

            applyTranscriptToPassage(transcript, options);
            return true;
        } catch (error) {
            lastBackendSttError = String(error?.message || error || "Unknown STT error");
            console.warn("Backend STT endpoint failed:", endpoint, error);
        }
    }

    return false;
}

function applyTranscriptToPassage(transcript, options = {}) {
    const cleanTranscript = String(transcript || "").trim();
    if (!cleanTranscript || !wordElements.length) return;

    const hasProcessingCap = Number.isInteger(options.maxProcessIndex);
    const maxProcessIndex = hasProcessingCap
        ? Math.max(-1, Math.min(options.maxProcessIndex, wordElements.length - 1))
        : wordElements.length - 1;

    if (hasProcessingCap && maxProcessIndex < 0) {
        wordElements.forEach((el) => {
            if (!el) return;
            el.dataset.readCounted = "0";
            scheduleDomUpdate(() => {
                el.classList.remove("current-word");
                clearWordStateClasses(el);
            });
        });
        flushDomUpdates();
        currentWordIndex = 0;
        totalWordsRead = 0;
        highlightCurrentWord();
        resetHesitation();
        return;
    }

    currentWordIndex = 0;
    totalWordsRead = 0;
    activeSentenceIndex = 0;

    wordElements.forEach((el, index) => {
        if (!el) return;

        if (!hasProcessingCap || index <= maxProcessIndex) {
            el.dataset.readCounted = "0";
        }

        scheduleDomUpdate(() => {
            el.classList.remove("current-word");
            if (!hasProcessingCap || index <= maxProcessIndex) {
                clearWordStateClasses(el);
            }
        });
    });

    flushDomUpdates();
    highlightCurrentWord();
    resetHesitation();

    handleVoiceInput(cleanTranscript, {
        allowErrors: true,
        confidence: 1,
        isFinal: true,
        maxProcessIndex
    });

    flushDomUpdates();

    if (hasProcessingCap) {
        for (let index = maxProcessIndex + 1; index < wordElements.length; index++) {
            const el = wordElements[index];
            if (!el) continue;
            el.dataset.readCounted = "0";
            scheduleDomUpdate(() => {
                clearWordStateClasses(el);
                el.classList.remove("current-word");
            });
        }
        flushDomUpdates();
        currentWordIndex = Math.min(currentWordIndex, maxProcessIndex + 1);
        lastHighlightedIndex = -1;
        highlightCurrentWord();
    }
}

function estimateTranscriptPassageQuality(transcript) {
    const spokenWords = String(transcript || "")
        .toLowerCase()
        .replace(/[^\w\s']/g, "")
        .split(/\s+/)
        .map(normalizeWord)
        .filter((word) => word && word.length >= INTERIM_MIN_TOKEN_LENGTH);

    if (!spokenWords.length || !normalizedPassageWords.length) {
        return {
            matchedWords: 0,
            totalWords: spokenWords.length,
            matchRatio: 0
        };
    }

    let matchedWords = 0;
    let searchStart = 0;

    for (const spokenWord of spokenWords) {
        const matchIndex = findLookaheadMatch(
            spokenWord,
            searchStart,
            8,
            normalizedPassageWords.length - 1
        );

        if (matchIndex === -1) {
            continue;
        }

        matchedWords++;
        searchStart = matchIndex + 1;

        if (searchStart >= normalizedPassageWords.length) {
            break;
        }
    }

    return {
        matchedWords,
        totalWords: spokenWords.length,
        matchRatio: matchedWords / Math.max(spokenWords.length, 1)
    };
}

function arrayBufferToBase64(buffer) {
    let binary = "";
    const bytes = new Uint8Array(buffer);
    const chunkSize = 0x8000;

    for (let i = 0; i < bytes.length; i += chunkSize) {
        const chunk = bytes.subarray(i, i + chunkSize);
        binary += String.fromCharCode(...chunk);
    }

    return btoa(binary);
}

function applyAzureWordAssessment(azureWords) {
    let pointer = 0;

    azureWords.forEach((wordResult) => {
        const spokenWord = normalizeWord(wordResult.word);
        const errorType = String(wordResult.errorType || "").toLowerCase();
        const accuracyScore = Number(wordResult.accuracyScore || 100);

        while (pointer < wordElements.length) {
            const targetWord = normalizeWord(wordElements[pointer].innerText);

            if (!targetWord) {
                pointer++;
                continue;
            }

            if (errorType === "omission") {
                markWordAsError(pointer, "omit-error");
                pointer++;
                return;
            }

            if (isAcceptableWordMatch(spokenWord, targetWord)) {
                if (errorType === "mispronunciation" || accuracyScore < AZURE_MISPRONUNCIATION_ACCURACY_THRESHOLD) {
                    markWordAsError(pointer, "mis-error");
                } else if (errorType === "insertion") {
                    markWordAsError(pointer, "add-error");
                } else if (errorType === "substitution") {
                    markWordAsError(pointer, "sub-error");
                } else if (errorType === "omission") {
                    markWordAsError(pointer, "omit-error");
                } else {
                    markWordAsRead(pointer, false);
                }

                pointer++;
                return;
            }

            pointer++;
        }
    });

    flushDomUpdates();
    totalWordsRead = wordElements.filter(el => el.classList.contains("read-success")).length;
}

function stopStopwatch() {
    clearInterval(stopwatchInterval);
}

function renderQuiz(questions) {
    let quizHTML = "";
    questions.forEach((item, qIdx) => {
        quizHTML += `
            <div class="question-item">
                <p><strong>${qIdx + 1}. ${item.q}</strong></p>
                ${item.options.map((opt, oIdx) => `
                    <label class="option-label">
                        <input type="radio" name="q${qIdx}" value="${oIdx}"> ${opt}
                    </label>
                `).join('')}
            </div>
        `;
    });
    document.getElementById("quizArea").innerHTML = quizHTML;
}

function startBackendOnlyRecordingSession() {
    isRecording = true;
    shouldAutoRestartRecognition = true;
    lastRecognitionEventAt = 0;
    lastRecognitionRestartAt = 0;
    recognitionNoEventRestartCount = 0;
    hasShownLiveHighlightFallbackNotice = false;
    recognitionSessionStartedAt = Date.now();

    startTime = Date.now();
    currentWordIndex = 0;
    totalWordsRead = 0;
    liveTranscriptCursor = "";
    liveResultSegments.clear();
    pendingSpeechQueue = [];
    speechQueueHandle = null;
    activeSentenceIndex = 0;
    lastSpeechAssistAdvanceAt = 0;
    lastSpeechAssistTranscript = "";

    wordElements.forEach((el) => {
        if (!el) return;
        el.dataset.readCounted = "0";
        scheduleDomUpdate(() => {
            el.classList.remove("current-word");
            clearWordStateClasses(el);
        });
    });
    lastHighlightedIndex = -1;
    highlightCurrentWord();

    document.getElementById("startReadingBtn").innerText = "🛑 STOP RECORDING";
    document.getElementById("startReadingBtn").style.background = "#c0392b";

    startStopwatch();
    startAudioRecording();
}

function handleRecognitionResultEvent(event) {
    if (!isRecording) return;

    lastRecognitionEventAt = Date.now();
    recognitionNoEventRestartCount = 0;

    for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        const transcript = result?.[0]?.transcript || "";
        const rawConfidence = result?.[0]?.confidence;
        const confidence = (typeof rawConfidence === "number" && rawConfidence > 0) ? rawConfidence : null;
        const isFinal = result.isFinal === true;

        // Ignore weak or likely-noise chunks before they can mutate reading state.
        if (!isFinal && confidence !== null && confidence < INTERIM_PROCESS_MIN_CONFIDENCE) {
            continue;
        }

        if (isFinal && confidence !== null && confidence < FINAL_PROCESS_MIN_CONFIDENCE) {
            continue;
        }

        const deltaWords = getDeltaWordsFromResultSegment(i, transcript, isFinal);

        if (!isFinal && deltaWords.length < 1) {
            continue;
        }

        if (!deltaWords.length) {
            maybeAssistProgressFromSpeech(result, transcript);
            continue;
        }

        if (!isFinal) {
            // Use the full matcher for interim chunks so highlights move while the user is still speaking.
            handleVoiceInput(deltaWords.join(" "), {
                allowErrors: false,
                confidence: confidence ?? 1,
                isFinal: false
            });
            continue;
        }

        enqueueSpeechWords(deltaWords.join(" "), {
            allowErrors: isFinal,
            confidence,
            isFinal
        });
    }
}

async function startFluencyTest() {
    if (!examStarted) {
        showAppAlert("Start Exam first before using Oral Reading & Fluency.", "Exam Not Started");
        return;
    }

    // Toggle behavior so the same button can start/stop recording.
    if (isRecording) {
        stopFluencyTest();
        return;
    }

    const hasMicrophoneAccess = await ensureMicrophonePermission();
    if (!hasMicrophoneAccess) {
        return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

    if (USE_BACKEND_STT_MODE) {
        startBackendOnlyRecordingSession();

        if (SpeechRecognition) {
            recognition = new SpeechRecognition();
            recognition.continuous = true;
            recognition.interimResults = true;
            recognition.maxAlternatives = 1;
            recognition.lang = BROWSER_RECOGNITION_LANG;

            recognition.onresult = handleRecognitionResultEvent;
            recognition.onerror = (e) => {
                // Keep backend recording active even if browser live preview fails.
                console.warn("Live preview speech error:", e.error);

                if (isRecording && shouldAutoRestartRecognition) {
                    scheduleRecognitionRestart();
                }
            };
            recognition.onend = () => {
                if (isRecording && shouldAutoRestartRecognition) {
                    scheduleRecognitionRestart();
                    return;
                }
                console.log("Live preview recognition stopped");
            };

            try {
                recognition.start();
                startRecognitionWatchdog();
            } catch (error) {
                console.warn("Live preview recognition could not start:", error);
            }
        } else {
            showAppAlert(
                "Live word highlights are not supported on this browser. Final transcript scoring will appear after stopping recording.",
                "Limited Live Highlight"
            );
        }

        return;
    }

    if (!SpeechRecognition) {
        showAppAlert("Please use Chrome browser for speech recognition support.", "Browser Required");
        return;
    }

    recognition = new SpeechRecognition();

    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;
    recognition.lang = BROWSER_RECOGNITION_LANG;

    recognition.onstart = () => {
        isRecording = true;
        shouldAutoRestartRecognition = true;
        lastRecognitionEventAt = 0;
        lastRecognitionRestartAt = 0;
        recognitionNoEventRestartCount = 0;
        hasShownLiveHighlightFallbackNotice = false;
        recognitionSessionStartedAt = Date.now();

        startTime = Date.now();
        currentWordIndex = 0;
        totalWordsRead = 0;
        liveTranscriptCursor = "";
        liveResultSegments.clear();
        pendingSpeechQueue = [];
        speechQueueHandle = null;
        activeSentenceIndex = 0;
        lastSpeechAssistAdvanceAt = 0;
        lastSpeechAssistTranscript = "";

        wordElements.forEach((el) => {
            if (!el) return;
            el.dataset.readCounted = "0";
            scheduleDomUpdate(() => {
                el.classList.remove("current-word");
                clearWordStateClasses(el);
            });
        });
        lastHighlightedIndex = -1;
        highlightCurrentWord();

        document.getElementById("startReadingBtn").innerText = "🛑 STOP RECORDING";
        document.getElementById("startReadingBtn").style.background = "#c0392b";

        startStopwatch();
        startAudioRecording().then((started) => {
            if (!started && isRecording) {
                showAppAlert(
                    "Microphone recording did not start. Please check microphone access and try again.",
                    "Microphone Error"
                );
                stopFluencyTest();
            }
        });
        startHesitationTimer();
        startRecognitionWatchdog();
    };

    recognition.onresult = handleRecognitionResultEvent;

    recognition.onerror = (e) => {
        console.log("Speech error:", e.error);
        stopFluencyTest();
    };

    recognition.onend = () => {
        if (isRecording && shouldAutoRestartRecognition) {
            scheduleRecognitionRestart();
            return;
        }
        console.log("Recognition stopped");
    };

    recognition.start();
}

function buildCombinedTranscript(results) {
    let combined = "";

    for (let i = 0; i < results.length; i++) {
        const segment = results[i]?.[0]?.transcript || "";
        if (segment) {
            combined += segment + " ";
        }
    }

    return combined.trim();
}

function handleVoiceInput(spokenText, options = { allowErrors: true, confidence: 1, isFinal: false }) {
    if (currentWordIndex >= wordElements.length) return;

    const allowErrors = options.allowErrors !== false;
    const recognitionConfidence = typeof options.confidence === "number" ? options.confidence : 1;
    const isFinalResult = options.isFinal === true;
    const hasProcessCap = Number.isInteger(options.maxProcessIndex);
    const processCapIndex = hasProcessCap
        ? Math.max(-1, Math.min(options.maxProcessIndex, wordElements.length - 1))
        : wordElements.length - 1;

    if (hasProcessCap && currentWordIndex > processCapIndex) return;

    const spokenWords = spokenText
        .toLowerCase()
        .replace(/[^\w\s']/g, "")
        .split(/\s+/)
        .filter(Boolean);

    const startWordIndex = currentWordIndex;
    syncSentencePointerToCurrentWord();

    for (let i = 0; i < spokenWords.length; i++) {
        if (currentWordIndex >= wordElements.length || currentWordIndex > processCapIndex) {
            break;
        }

        syncSentencePointerToCurrentWord();
        const currentSentence = getCurrentSentenceRange();
        const currentSentenceEnd = Math.min(currentSentence.end, wordElements.length - 1, processCapIndex);

        const targetWord = getTargetWordAt(currentWordIndex);
        const normalizedSpokenWord = normalizeWord(spokenWords[i]);
        const nextSpokenWord = normalizeWord(spokenWords[i + 1]);
        const nextTargetWord = currentWordIndex + 1 <= processCapIndex
            ? getTargetWordAt(currentWordIndex + 1)
            : "";

        if (!normalizedSpokenWord) {
            continue;
        }

        if (isAcceptableWordMatch(normalizedSpokenWord, targetWord)) {
            // Final low-confidence hits are treated as likely pronunciation issues.
            if (isFinalResult && recognitionConfidence < LOW_CONFIDENCE_MISPRONUNCIATION_THRESHOLD) {
                markWordAsError(currentWordIndex, "mis-error");
            } else {
                markWordAsRead(currentWordIndex);
            }

            currentWordIndex++;
            highlightCurrentWord();
            resetHesitation();

            continue;
        }

        const lookaheadWindow = Math.max(FAST_READING_LOOKAHEAD, currentSentenceEnd - currentWordIndex);
        const lookaheadMatchIndex = findLookaheadMatch(
            normalizedSpokenWord,
            currentWordIndex + 1,
            lookaheadWindow,
            currentSentenceEnd
        );

        if (lookaheadMatchIndex > currentWordIndex + 1) {
            while (currentWordIndex < lookaheadMatchIndex) {
                markWordAsError(currentWordIndex, "omit-error");
                currentWordIndex++;
            }

            markWordAsRead(currentWordIndex);
            currentWordIndex++;
            highlightCurrentWord();
            resetHesitation();
            continue;
        }

        if (lookaheadMatchIndex === currentWordIndex + 1) {
            markWordAsError(currentWordIndex, "omit-error");
            currentWordIndex++;
            markWordAsRead(currentWordIndex);
            currentWordIndex++;
            highlightCurrentWord();
            resetHesitation();
            continue;
        }

        // If spoken token appears in the next sentence, close current sentence with omissions and hand off.
        const nextSentence = sentenceRanges[activeSentenceIndex + 1];
        if (nextSentence) {
            const nextSentenceSpan = Math.max(FAST_READING_LOOKAHEAD, nextSentence.end - nextSentence.start + 1);
            const nextSentenceMatch = findLookaheadMatch(
                normalizedSpokenWord,
                nextSentence.start,
                nextSentenceSpan,
                nextSentence.end
            );

            if (nextSentenceMatch !== -1) {
                while (currentWordIndex < nextSentenceMatch) {
                    markWordAsError(currentWordIndex, "omit-error");
                    currentWordIndex++;
                }

                syncSentencePointerToCurrentWord();

                markWordAsRead(currentWordIndex);
                currentWordIndex++;
                highlightCurrentWord();
                resetHesitation();
                continue;
            }
        }

        // During interim recognition, only fast-path correct matches to keep UI smooth.
        if (!allowErrors) {
            continue;
        }

        // Omission: spoken word matches the next expected word, so current word was skipped.
        if (isAcceptableWordMatch(normalizedSpokenWord, nextTargetWord)) {
            markWordAsError(currentWordIndex, "omit-error");
            currentWordIndex++;

            if (currentWordIndex < wordElements.length) {
                markWordAsRead(currentWordIndex);
                currentWordIndex++;
            }

            highlightCurrentWord();
            resetHesitation();

            continue;
        }

        // Addition: an extra spoken word appears before the expected target word.
        if (nextSpokenWord && isAcceptableWordMatch(nextSpokenWord, targetWord)) {
            markWordAsError(currentWordIndex, "add-error");
            highlightCurrentWord();
            resetHesitation();

            continue;
        }

        determineErrorType(normalizedSpokenWord, targetWord, recognitionConfidence);
        highlightCurrentWord();
    }

    // If a final chunk still produced no movement, align at sentence scope so fast readers don't get stuck.
    if (
        isFinalResult &&
        recognitionConfidence >= LOW_CONFIDENCE_MISPRONUNCIATION_THRESHOLD &&
        currentWordIndex === startWordIndex &&
        spokenWords.length >= 3
    ) {
        applyFinalSentenceFallback(spokenWords, recognitionConfidence, processCapIndex);
    }

    if (currentWordIndex >= wordElements.length || currentWordIndex > processCapIndex) {
        stopFluencyTest();
    }
}

function getDeltaWordsFromTranscript(transcript, isFinal) {
    const normalizedTranscript = transcript
        .toLowerCase()
        .replace(/[^\w\s']/g, "")
        .trim();

    if (!normalizedTranscript) {
        if (isFinal) {
            liveTranscriptCursor = "";
        }
        return [];
    }

    const currentWords = normalizedTranscript.split(/\s+/).filter(Boolean);
    const previousWords = liveTranscriptCursor.split(/\s+/).filter(Boolean);

    let commonPrefixLength = 0;
    while (
        commonPrefixLength < previousWords.length &&
        commonPrefixLength < currentWords.length &&
        previousWords[commonPrefixLength] === currentWords[commonPrefixLength]
    ) {
        commonPrefixLength++;
    }

    const deltaWords = currentWords.slice(commonPrefixLength);

    if (isFinal) {
        liveTranscriptCursor = "";
    } else {
        liveTranscriptCursor = normalizedTranscript;
    }

    return deltaWords;
}

function getDeltaWordsFromResultSegment(segmentIndex, transcript, isFinal) {
    const normalizedTranscript = (transcript || "")
        .toLowerCase()
        .replace(/[^\w\s']/g, "")
        .trim();

    const previousTranscript = liveResultSegments.get(segmentIndex) || "";
    const currentWords = normalizedTranscript ? normalizedTranscript.split(/\s+/).filter(Boolean) : [];
    const previousWords = previousTranscript ? previousTranscript.split(/\s+/).filter(Boolean) : [];

    let commonPrefixLength = 0;
    while (
        commonPrefixLength < previousWords.length &&
        commonPrefixLength < currentWords.length &&
        previousWords[commonPrefixLength] === currentWords[commonPrefixLength]
    ) {
        commonPrefixLength++;
    }

    if (isFinal) {
        liveResultSegments.delete(segmentIndex);
    } else {
        liveResultSegments.set(segmentIndex, normalizedTranscript);
    }

    return currentWords.slice(commonPrefixLength);
}


function startHesitationTimer() {
    clearInterval(hesitationInterval);
    hesitationSeconds = 0;
    hesitationInterval = setInterval(() => {
        hesitationSeconds++;
        if (hesitationSeconds >= 5) {
            if (wordElements[currentWordIndex]) {
                markWordAsError(currentWordIndex, "add-error");
            }
            currentWordIndex++;
            highlightCurrentWord();
            resetHesitation();

            if (currentWordIndex >= wordElements.length) {
                stopFluencyTest();
            }
        }
    }, 1000);
}

function resetHesitation() {
    hesitationSeconds = 0;
}

function determineErrorType(spoken, target, confidence = 1) {
    if (isAcceptableWordMatch(spoken, target)) {
        markWordAsRead(currentWordIndex);
        currentWordIndex++;
        resetHesitation();
        return;
    }

    const baseLength = Math.max(spoken.length, target.length, 1);
    const distance = levenshteinDistance(spoken, target);
    const similarity = 1 - distance / baseLength;

    if (similarity >= MISPRONUNCIATION_SIMILARITY_THRESHOLD || confidence < LOW_CONFIDENCE_MISPRONUNCIATION_THRESHOLD) {
        markWordAsError(currentWordIndex, "mis-error"); // Blue
    } else {
        markWordAsError(currentWordIndex, "sub-error"); // Red
    }

    currentWordIndex++;
    resetHesitation();
}

async function stopFluencyTest() {
    if (!isRecording) return;

    shouldAutoRestartRecognition = false;
    if (recognitionRestartHandle) {
        clearTimeout(recognitionRestartHandle);
        recognitionRestartHandle = null;
    }
    stopRecognitionWatchdog();

    // Capture late-arriving chunks before hard stop.
    flushPendingSpeechQueueImmediately();
    if (recognition) {
        await waitForRecognitionDrain(180);
        flushPendingSpeechQueueImmediately();
    }

    const trailingInterimTranscript = getPendingInterimTranscriptSnapshot();
    const hasFreshTail = Date.now() - lastRecognitionEventAt <= 450;
    if (trailingInterimTranscript && hasFreshTail) {
        handleVoiceInput(trailingInterimTranscript, {
            allowErrors: false,
            confidence: 1,
            isFinal: false
        });
        flushPendingSpeechQueueImmediately();
    }

    const stopBoundaryIndex = currentWordIndex - 1;
    isRecording = false;

    if (recognition) {
        try {
            recognition.onresult = null;
            recognition.onend = null;
            recognition.onerror = null;

            recognition.abort(); // 🔥 HARD STOP
        } catch (e) {}

        recognition = null;
    }

    clearInterval(hesitationInterval);
    stopStopwatch();
    liveTranscriptCursor = "";
    pendingSpeechQueue = [];
    speechQueueHandle = null;
    liveResultSegments.clear();
    activeSentenceIndex = 0;
    lastSpeechAssistTranscript = "";
    lastRecognitionRestartAt = 0;
    recognitionSessionStartedAt = 0;
    recognitionNoEventRestartCount = 0;
    hasShownLiveHighlightFallbackNotice = false;
    stopStrictNoiseMonitor();

    const recordedAudioBlob = await stopAudioRecordingAndGetBlob();
    let backendSttApplied = false;

    if (recordedAudioBlob) {
        backendSttApplied = await applyBackendSttTranscription(recordedAudioBlob, {
            maxProcessIndex: stopBoundaryIndex
        });
    }

    if (USE_BACKEND_STT_MODE && !backendSttApplied) {
        if (lastBackendSttError.startsWith("Low transcript overlap")) {
            showAppAlert(
                "Backend transcript quality was too low, so the system kept your live reading result.",
                "Using Live Result"
            );
        } else {
            showAppAlert(
                `Could not transcribe audio from backend STT. ${lastBackendSttError || "Check API key and function logs."}`,
                "Transcription Unavailable"
            );
        }
    }

    if (recordedAudioBlob) {
        await applyAzurePronunciationAssessment(recordedAudioBlob);
    }

    document.getElementById("startReadingBtn").innerText = "🎤 START READING ALOUD";
    document.getElementById("startReadingBtn").style.background = "#27ae60";

    showFluencyResults();
}
function showFluencyResults() {
    const timeElapsed = Math.max(stopwatchSeconds / 60, 1 / 60);
    const wpm = Math.round(totalWordsRead / timeElapsed || 0);

    const accuracy = Math.round((totalWordsRead / wordElements.length) * 100);

    currentFluencyMetrics = {
        wordsRead: totalWordsRead,
        totalWords: wordElements.length,
        wpm,
        accuracyPercent: accuracy
    };

    const resultsDashEl = document.getElementById("resultsDash");
    const scoreValueEl = document.getElementById("scoreValue");
    if (resultsDashEl) {
        resultsDashEl.style.display = "block";
    }
    if (scoreValueEl) {
        scoreValueEl.innerText = `${totalWordsRead}/${wordElements.length}`;
    }

    showAppAlert(`WPM: ${wpm}\nAccuracy: ${accuracy}%`, "Accuracy Score");
}

let currentLevel = "";
let currentPassageIndex = 0;
let score = 0;
let currentPassageOrder = 1;
let currentPassageTotal = 0;
let currentAttemptId = null;
let currentFluencyMetrics = {
    wordsRead: 0,
    totalWords: 0,
    wpm: 0,
    accuracyPercent: 0
};

function resolveExamApiBase() {
    const host = String(window.location.hostname || "").toLowerCase();
    const isNetlifyHost = host.endsWith("netlify.app") || host.endsWith("netlify.live");
    const isLocalHost = host === "localhost" || host === "127.0.0.1";

    if (isNetlifyHost) {
        return "";
    }

    if (isLocalHost) {
        return "https://word-harbor.netlify.app";
    }

    return "";
}

const EXAM_API_BASE = resolveExamApiBase();

function buildExamFunctionUrl(path) {
    if (!EXAM_API_BASE) {
        return path;
    }

    return `${EXAM_API_BASE}${path}`;
}

async function requestExamJson(url, payload) {
    const response = await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
    });

    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result.ok) {
        const coreMessage = result?.error || `Request failed with status ${response.status}`;
        const detailsMessage = String(result?.details || "").trim();
        throw new Error(detailsMessage ? `${coreMessage}: ${detailsMessage}` : coreMessage);
    }

    return result;
}

async function startStudentAttemptRecord(studentName, level, passageTitle) {
    const result = await requestExamJson(
        buildExamFunctionUrl("/.netlify/functions/student-attempt-start"),
        {
            studentName,
            level,
            passageTitle
        }
    );

    return Number(result?.attempt?.id || 0) || null;
}

async function completeStudentAttemptRecord(attemptId, comprehensionScore, comprehensionTotal) {
    if (!attemptId) return;

    await requestExamJson(
        buildExamFunctionUrl("/.netlify/functions/student-attempt-complete"),
        {
            attemptId,
            fluencyWordsRead: currentFluencyMetrics.wordsRead,
            fluencyTotalWords: currentFluencyMetrics.totalWords,
            wpm: currentFluencyMetrics.wpm,
            accuracyPercent: currentFluencyMetrics.accuracyPercent,
            comprehensionScore,
            comprehensionTotal
        }
    );
}

function buildQuizHtml(data) {
    let quizHTML = "";

    data.questions.forEach((item, qIdx) => {
        const displayQuestionNumber = qIdx + 1;
        quizHTML += `
            <div class="question-item">
                <span class="question-text">${displayQuestionNumber}. ${item.q}</span>
                ${item.options.map((opt, oIdx) => {
    const letter = String.fromCharCode(65 + oIdx);
    return `
        <label class="option-label">
            <input type="radio" name="q${qIdx}" value="${oIdx}">
            <strong>${letter}.</strong> ${opt}
        </label>
    `;
}).join("")}
            </div>
        `;
    });

    return quizHTML;
}

function showExamInterface() {
    const inputContainerEl = document.getElementById("inputContainer");
    if (inputContainerEl) {
        inputContainerEl.style.display = "none";
    }

    const assessmentPagesPanelEl = document.getElementById("assessmentPagesPanel");
    if (assessmentPagesPanelEl) {
        assessmentPagesPanelEl.style.display = "block";
    }

    const examAreaEl = document.getElementById("examArea");
    if (examAreaEl) {
        examAreaEl.style.display = "";
    }

    const submitBtnEl = document.getElementById("submitBtn");
    if (submitBtnEl) {
        submitBtnEl.style.display = "block";
    }
}

function persistExamSessionState(studentName) {
    const payload = {
        studentName: String(studentName || "").trim(),
        level: currentLevel,
        passageIndex: currentPassageIndex,
        passageOrder: currentPassageOrder,
        passageTotal: currentPassageTotal,
        attemptId: currentAttemptId
    };

    localStorage.setItem("activeExamSession", JSON.stringify(payload));
}

function updatePassageIndicator() {
    const indicatorEl = document.getElementById("passageIndicator");
    if (!indicatorEl || !currentPassageData) return;

    const questionCount = Array.isArray(currentPassageData.questions) ? currentPassageData.questions.length : 0;
    const questionStart = questionCount > 0 ? 1 : 0;
    const questionEnd = questionCount;

    indicatorEl.innerText = `Passage ${currentPassageOrder} of ${currentPassageTotal || "-"} • Questions ${questionStart}-${questionEnd}`;
    indicatorEl.style.display = "block";
}

function restoreExamSessionOnIndex() {
    const inputContainerEl = document.getElementById("inputContainer");
    const examAreaEl = document.getElementById("examArea");
    const studentNameEl = document.getElementById("studentName");
    const levelSelectEl = document.getElementById("level");
    const quizAreaEl = document.getElementById("quizArea");
    const passageTitleEl = document.getElementById("passageTitle");

    if (!inputContainerEl || !examAreaEl || !studentNameEl || !levelSelectEl || !quizAreaEl || !passageTitleEl) {
        return false;
    }

    let session;
    try {
        session = JSON.parse(localStorage.getItem("activeExamSession") || "null");
    } catch (error) {
        session = null;
    }

    if (!session?.level) {
        return false;
    }

    const levelData = assessmentData[session.level];
    const index = Number(session.passageIndex);

    if (!Array.isArray(levelData) || Number.isNaN(index) || index < 0 || index >= levelData.length) {
        return false;
    }

    const restoredStudentName = String(session.studentName || localStorage.getItem("lastStudentName") || "").trim();
    if (restoredStudentName) {
        studentNameEl.value = restoredStudentName;
    }

    levelSelectEl.value = session.level;
    currentLevel = session.level;
    currentPassageIndex = index;
    currentPassageTotal = levelData.length;
    currentPassageOrder = Math.min(
        Math.max(Number(session.passageOrder) || index + 1, 1),
        Math.max(levelData.length, 1)
    );
    currentPassageData = levelData[index];
    currentAttemptId = Number(session.attemptId || 0) || null;
    examStarted = true;

    passageTitleEl.innerText = currentPassageData.title;
    preparePassageForFluency(currentPassageData.text);
    quizAreaEl.innerHTML = buildQuizHtml(currentPassageData);
    updatePassageIndicator();

    showExamInterface();

    const startReadingBtn = document.getElementById("startReadingBtn");
    if (startReadingBtn) {
        startReadingBtn.disabled = false;
    }

    return true;
}

function getUsedPassagesByLevel() {
    try {
        const raw = JSON.parse(localStorage.getItem("usedPassagesByLevel") || "{}");
        return raw && typeof raw === "object" ? raw : {};
    } catch (error) {
        return {};
    }
}

function setUsedPassagesByLevel(value) {
    localStorage.setItem("usedPassagesByLevel", JSON.stringify(value || {}));
}

function selectSequentialPassageIndex(level, levelData, isNextRequest) {
    const usedByLevel = getUsedPassagesByLevel();
    const usedForLevel = Array.isArray(usedByLevel[level]) ? [...usedByLevel[level]] : [];

    const isNewExamStart = !isNextRequest || currentLevel !== level || !examStarted;

    if (isNewExamStart) {
        usedForLevel.length = 0;
        usedForLevel.push(0);
        usedByLevel[level] = usedForLevel;
        setUsedPassagesByLevel(usedByLevel);
        return {
            index: 0,
            order: 1,
            total: levelData.length
        };
    }

    const lastShownIndex = usedForLevel.length ? usedForLevel[usedForLevel.length - 1] : 0;
    let nextIndex = (lastShownIndex + 1) % levelData.length;

    if (usedForLevel.length >= levelData.length) {
        usedForLevel.length = 0;
        showAppAlert("You have reached the last passage for this level. Restarting from passage 1.", "Passage Cycle Complete");
    }

    usedForLevel.push(nextIndex);
    usedByLevel[level] = usedForLevel;
    setUsedPassagesByLevel(usedByLevel);

    return {
        index: nextIndex,
        order: usedForLevel.length,
        total: levelData.length
    };
}


function renderSelectedPassage(data) {
    document.getElementById("passageTitle").innerText = data.title;
    currentPassageData = data;
    currentFluencyMetrics = {
        wordsRead: 0,
        totalWords: 0,
        wpm: 0,
        accuracyPercent: 0
    };
    preparePassageForFluency(data.text);
    updatePassageIndicator();

    const quizHTML = buildQuizHtml(data);

    document.getElementById("quizArea").innerHTML = quizHTML;
    showExamInterface();

    document.getElementById("examArea").style.display = "";
    document.getElementById("submitBtn").style.display = "block";
    const resultsDashEl = document.getElementById("resultsDash");
    if (resultsDashEl) {
        resultsDashEl.style.display = "none";
    }

    const startReadingBtn = document.getElementById("startReadingBtn");
    if (startReadingBtn) {
        startReadingBtn.disabled = false;
    }

    stopStopwatch();
    stopwatchSeconds = 0;
    updateStopwatchDisplay();

    document.getElementById("examArea").scrollIntoView({ behavior: "smooth" });
}

async function loadPreviousPassage() {
    if (!examStarted) {
        showAppAlert("Start exam first before going to previous passage.", "Exam Not Started");
        return;
    }

    const selectedLevel = document.getElementById("level")?.value || currentLevel;
    const levelData = assessmentData[selectedLevel];
    if (!Array.isArray(levelData) || !levelData.length) {
        showAppAlert("No passages available for the selected level.", "No Passage");
        return;
    }

    const usedByLevel = getUsedPassagesByLevel();
    const usedForLevel = Array.isArray(usedByLevel[selectedLevel]) ? [...usedByLevel[selectedLevel]] : [];

    if (usedForLevel.length <= 1) {
        showAppAlert("You are already on the first passage for this level.", "First Passage");
        return;
    }

    usedForLevel.pop();
    const previousIndex = usedForLevel[usedForLevel.length - 1];
    usedByLevel[selectedLevel] = usedForLevel;
    setUsedPassagesByLevel(usedByLevel);

    currentLevel = selectedLevel;
    currentPassageTotal = levelData.length;
    currentPassageOrder = usedForLevel.length;
    currentPassageIndex = previousIndex;
    examStarted = true;

    const effectiveName = String(
        document.getElementById("studentName")?.value || localStorage.getItem("lastStudentName") || ""
    ).trim();
    if (effectiveName) {
        localStorage.setItem("lastStudentName", effectiveName);
    }

    currentAttemptId = null;
    try {
        currentAttemptId = await startStudentAttemptRecord(
            effectiveName,
            currentLevel,
            levelData[currentPassageIndex]?.title || ""
        );
    } catch (error) {
        console.warn("Could not start student attempt record:", error);
    }

    persistExamSessionState(effectiveName);
    renderSelectedPassage(levelData[currentPassageIndex]);
}

async function loadPassage(isNextRequest = false) {
    currentLevel = document.getElementById("level").value;
    const levelData = assessmentData[currentLevel];

    const studentNameEl = document.getElementById("studentName");
    const typedName = String(studentNameEl?.value || "").trim();
    const savedName = String(localStorage.getItem("lastStudentName") || "").trim();
    const effectiveName = typedName || savedName;

    if (!isNextRequest && !typedName) {
        showAppAlert("Please enter Student Name before starting.", "Missing Student Name");
        return;
    }

    if (isNextRequest && !effectiveName) {
        showAppAlert("No active student session found. Please start exam first.", "Session Required");
        return;
    }

    if (studentNameEl && !studentNameEl.value && effectiveName) {
        studentNameEl.value = effectiveName;
    }

    localStorage.setItem("lastStudentName", effectiveName);
    localStorage.setItem("latestAssessmentLevel", currentLevel);

    examStarted = true;

    const passageSelection = selectSequentialPassageIndex(currentLevel, levelData, isNextRequest);
    currentPassageIndex = passageSelection.index;
    currentPassageOrder = passageSelection.order;
    currentPassageTotal = passageSelection.total;
    const data = levelData[currentPassageIndex];

    currentAttemptId = null;
    try {
        currentAttemptId = await startStudentAttemptRecord(effectiveName, currentLevel, data?.title || "");
    } catch (error) {
        console.warn("Could not start student attempt record:", error);
    }

    persistExamSessionState(effectiveName);
    renderSelectedPassage(data);
}

function checkAnswers() {
    const data = assessmentData[currentLevel][currentPassageIndex];
    let userScore = 0;
    const total = data.questions.length;

    data.questions.forEach((item, idx) => {
        const selected = document.querySelector(`input[name="q${idx}"]:checked`);
        if (selected && parseInt(selected.value) === item.correct) {
            userScore++;
        }
    });

    score = userScore;
    const latestScore = `${userScore}/${total}`;
    localStorage.setItem("latestComprehensionScore", latestScore);
    localStorage.setItem("latestAssessmentLevel", currentLevel);

    const resultsDashEl = document.getElementById("resultsDash");
    const scoreValueEl = document.getElementById("scoreValue");
    if (resultsDashEl) {
        resultsDashEl.style.display = "block";
    }
    if (scoreValueEl) {
        scoreValueEl.innerText = latestScore;
    }

    const redirectBtn = document.getElementById("openComprehensionBtn");
    if (redirectBtn) {
        redirectBtn.disabled = false;
        shouldFocusComprehensionCtaAfterAlert = true;
    }

    completeStudentAttemptRecord(currentAttemptId, userScore, total)
        .then(() => {
            currentAttemptId = null;
        })
        .catch((error) => {
            console.warn("Could not save exam result to database:", error);
        });

    showAppAlert("Comprehension score is ready. Click 'View Comprehension Score' to open it.", "Score Ready");
}

function saveScore() {
    const nameInput = document.getElementById("studentName");
    const name = (nameInput?.value || localStorage.getItem("lastStudentName") || "").trim();
    if (!name) {
        showAppAlert("Please enter Student Name.", "Missing Student Name");
        return;
    }

    const scoreValueEl = document.getElementById("scoreValue");
    const scoreText = String(scoreValueEl?.innerText || localStorage.getItem("latestComprehensionScore") || "").trim();
    const levelText = currentLevel || localStorage.getItem("latestAssessmentLevel") || "-";

    if (!scoreText) {
        showAppAlert("No comprehension score found yet. Submit answers first.", "Score Missing");
        return;
    }

    const entry = {
        date: new Date().toLocaleString(),
        name,
        level: levelText,
        score: scoreText
    };

    let history = JSON.parse(localStorage.getItem("cellsHistory")) || [];
    history.unshift(entry);
    localStorage.setItem("cellsHistory", JSON.stringify(history));

    updateHistoryTable();
    showAppAlert("Record saved to history!", "Success");
}

function updateHistoryTable() {
    const history = JSON.parse(localStorage.getItem("cellsHistory")) || [];
    const historyBodyEl = document.getElementById("historyBody");
    if (!historyBodyEl) return;

    const html = history.map(item => `
        <tr>
            <td>${item.date}</td>
            <td>${item.name}</td>
            <td>${item.level}</td>
            <td>${item.score}</td>
        </tr>
    `).join("");
    historyBodyEl.innerHTML = html;
}

window.onload = async () => {
    const latestScore = localStorage.getItem("latestComprehensionScore") || "0/0";
    const scoreValueEl = document.getElementById("scoreValue");
    if (scoreValueEl) {
        scoreValueEl.innerText = latestScore;
    }

    const levelBadgeEl = document.getElementById("scoreLevelValue");
    if (levelBadgeEl) {
        levelBadgeEl.innerText = localStorage.getItem("latestAssessmentLevel") || "-";
    }

    updateHistoryTable();

    const restoredExam = restoreExamSessionOnIndex();

    const startReadingBtn = document.getElementById("startReadingBtn");
    if (startReadingBtn && !restoredExam) {
        startReadingBtn.disabled = true;
    }
};