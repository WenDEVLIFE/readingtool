# Teacher Auth Setup

This project now includes teacher login and account creation using Netlify Functions + Supabase.

## 1. Create tables in Supabase
Run the SQL files:

- `database/teacher_accounts.sql`
- `database/student_exam_records.sql`

## 2. Set Netlify environment variables
In Netlify site settings, add:

- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `TEACHER_AUTH_SECRET`

`TEACHER_AUTH_SECRET` should be a long random string (32+ chars).

## 3. Deploy
Deploy the site after setting env vars.

## Local testing note
- Netlify Functions do not run from plain XAMPP hosting by default.
- If you open the app locally, the teacher auth UI now falls back to `https://word-harbor.netlify.app`.
- You can override this by setting `window.TEACHER_API_BASE` in `teacher.html`.
- Alternative: run the project with Netlify Dev so `/.netlify/functions/*` works locally.

## 4. UI endpoints used
- `/.netlify/functions/teacher-register`
- `/.netlify/functions/teacher-login`
- `/.netlify/functions/student-attempt-start`
- `/.netlify/functions/student-attempt-complete`
- `/.netlify/functions/teacher-results-list`

## Notes
- Passwords are never stored as plain text.
- Passwords are hashed with Node `scrypt` + per-user salt.
- Login returns a signed token for teacher session usage.
- Student name + level + passage attempts are stored in Supabase and visible in Teacher Portal after login.
