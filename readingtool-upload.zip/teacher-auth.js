const AUTH_MODE_LOGIN = "login";
const AUTH_MODE_REGISTER = "register";

let authMode = AUTH_MODE_LOGIN;

function resolveTeacherApiBase() {
    const configuredBase = String(window.TEACHER_API_BASE || "").trim();
    if (configuredBase) {
        return configuredBase.replace(/\/$/, "");
    }

    const host = String(window.location.hostname || "").toLowerCase();
    const isNetlifyHost = host.endsWith("netlify.app") || host.endsWith("netlify.live");
    const isLocalHost = host === "localhost" || host === "127.0.0.1";

    if (isNetlifyHost) {
        return "";
    }

    if (isLocalHost) {
        // Default local fallback: call the deployed site functions when running from XAMPP or file preview.
        return "https://word-harbor.netlify.app";
    }

    return "";
}

const TEACHER_API_BASE = resolveTeacherApiBase();

function buildFunctionUrl(path) {
    if (!TEACHER_API_BASE) {
        return path;
    }

    return `${TEACHER_API_BASE}${path}`;
}

const loginTab = document.getElementById("loginTab");
const registerTab = document.getElementById("registerTab");
const teacherNameField = document.getElementById("teacherNameField");
const teacherNameInput = document.getElementById("teacherName");
const teacherEmailInput = document.getElementById("teacherEmail");
const teacherPasswordInput = document.getElementById("teacherPassword");
const submitAuthBtn = document.getElementById("submitAuthBtn");
const authForm = document.getElementById("teacherAuthForm");
const authStatus = document.getElementById("authStatus");
const sessionCard = document.getElementById("teacherSessionCard");
const sessionTeacherName = document.getElementById("sessionTeacherName");
const sessionTeacherEmail = document.getElementById("sessionTeacherEmail");
const logoutBtn = document.getElementById("logoutBtn");
const teacherResultsSection = document.getElementById("teacherResultsSection");
const teacherResultsStatus = document.getElementById("teacherResultsStatus");
const teacherResultsBody = document.getElementById("teacherResultsBody");
const refreshTeacherResultsBtn = document.getElementById("refreshTeacherResultsBtn");

function setAuthMode(mode) {
    authMode = mode;

    const isLogin = mode === AUTH_MODE_LOGIN;
    teacherNameField.style.display = isLogin ? "none" : "block";

    submitAuthBtn.innerText = isLogin ? "Login" : "Create Account";

    loginTab.classList.toggle("btn-secondary", !isLogin);
    registerTab.classList.toggle("btn-secondary", isLogin);
}

function showStatus(message, type) {
    authStatus.innerText = message;
    authStatus.className = `auth-status show ${type}`;
}

function clearStatus() {
    authStatus.innerText = "";
    authStatus.className = "auth-status";
}

function getStoredSession() {
    try {
        const raw = localStorage.getItem("teacherAuthSession");
        return raw ? JSON.parse(raw) : null;
    } catch (error) {
        return null;
    }
}

function setStoredSession(session) {
    localStorage.setItem("teacherAuthSession", JSON.stringify(session));
}

function clearStoredSession() {
    localStorage.removeItem("teacherAuthSession");
}

function showResultsStatus(message, type) {
    if (!teacherResultsStatus) return;
    teacherResultsStatus.innerText = message;
    teacherResultsStatus.className = `auth-status show ${type}`;
}

function clearResultsStatus() {
    if (!teacherResultsStatus) return;
    teacherResultsStatus.innerText = "";
    teacherResultsStatus.className = "auth-status";
}

function formatDateTime(value) {
    if (!value) return "-";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "-";
    return date.toLocaleString();
}

function renderTeacherResults(items) {
    if (!teacherResultsBody) return;

    if (!Array.isArray(items) || !items.length) {
        teacherResultsBody.innerHTML = `<tr><td colspan="6">No results yet.</td></tr>`;
        return;
    }

    teacherResultsBody.innerHTML = items
        .map((item) => {
            const fluencyText = `${item.fluencyWordsRead}/${item.fluencyTotalWords} • WPM ${item.wpm} • ${item.accuracyPercent}%`;
            const compText = `${item.comprehensionScore}/${item.comprehensionTotal}`;

            return `
                <tr>
                    <td>${formatDateTime(item.completedAt || item.createdAt)}</td>
                    <td>${item.studentName || "-"}</td>
                    <td>${item.level || "-"}</td>
                    <td>${item.passageTitle || "-"}</td>
                    <td>${fluencyText}</td>
                    <td>${compText}</td>
                </tr>
            `;
        })
        .join("");
}

async function loadTeacherResults() {
    const session = getStoredSession();
    const token = session?.token;
    if (!token) {
        renderTeacherResults([]);
        return;
    }

    clearResultsStatus();

    try {
        const response = await fetch(buildFunctionUrl("/.netlify/functions/teacher-results-list?limit=200"), {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`
            }
        });

        const result = await response.json().catch(() => ({}));
        if (!response.ok || !result.ok) {
            const errorMessage = String(result?.error || "Failed to load teacher results");
            const details = String(result?.details || "").trim();
            throw new Error(details ? `${errorMessage}: ${details}` : errorMessage);
        }

        renderTeacherResults(result.items || []);
        showResultsStatus("Results loaded.", "success");
    } catch (error) {
        renderTeacherResults([]);
        showResultsStatus(String(error?.message || error || "Failed to load teacher results"), "error");
    }
}

function renderSessionCard(session) {
    if (!session || !session.teacher) {
        sessionCard.classList.remove("show");
        sessionTeacherName.innerText = "-";
        sessionTeacherEmail.innerText = "-";
        if (teacherResultsSection) {
            teacherResultsSection.style.display = "none";
        }
        clearResultsStatus();
        return;
    }

    sessionTeacherName.innerText = session.teacher.fullName || "Teacher";
    sessionTeacherEmail.innerText = session.teacher.email || "-";
    sessionCard.classList.add("show");

    if (teacherResultsSection) {
        teacherResultsSection.style.display = "block";
    }

    loadTeacherResults();
}

async function requestJson(url, payload) {
    let response;

    try {
        response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        });
    } catch (networkError) {
        const host = String(window.location.hostname || "").toLowerCase();
        const isLocalHost = host === "localhost" || host === "127.0.0.1";

        throw new Error(
            isLocalHost
                ? "Could not reach auth server. If testing locally, deploy latest changes to Netlify or run with Netlify Dev."
                : "Network request failed while contacting auth server."
        );
    }

    const result = await response.json().catch(() => ({}));

    if (!response.ok || !result.ok) {
        const coreMessage = result?.error || `Request failed with status ${response.status}`;
        const detailsMessage = String(result?.details || "").trim();
        const message = detailsMessage
            ? `${coreMessage}: ${detailsMessage}`
            : coreMessage;
        throw new Error(message);
    }

    return result;
}

async function registerTeacher(fullName, email, password) {
    return requestJson(buildFunctionUrl("/.netlify/functions/teacher-register"), {
        fullName,
        email,
        password
    });
}

async function loginTeacher(email, password) {
    return requestJson(buildFunctionUrl("/.netlify/functions/teacher-login"), {
        email,
        password
    });
}

async function handleSubmit(event) {
    event.preventDefault();
    clearStatus();

    const fullName = teacherNameInput.value.trim();
    const email = teacherEmailInput.value.trim().toLowerCase();
    const password = teacherPasswordInput.value;

    if (!email || !password) {
        showStatus("Email and password are required.", "error");
        return;
    }

    if (authMode === AUTH_MODE_REGISTER) {
        if (!fullName) {
            showStatus("Teacher name is required for account creation.", "error");
            return;
        }

        if (password.length < 8) {
            showStatus("Use a password with at least 8 characters.", "error");
            return;
        }
    }

    submitAuthBtn.disabled = true;
    showStatus("Processing request...", "info");

    try {
        if (authMode === AUTH_MODE_REGISTER) {
            await registerTeacher(fullName, email, password);
            showStatus("Teacher account created. You can now login.", "success");
            setAuthMode(AUTH_MODE_LOGIN);
            teacherPasswordInput.value = "";
            return;
        }

        const result = await loginTeacher(email, password);
        setStoredSession({
            token: result.token,
            teacher: result.teacher,
            issuedAt: Date.now()
        });

        renderSessionCard(getStoredSession());
        showStatus("Login successful.", "success");
        teacherPasswordInput.value = "";
    } catch (error) {
        showStatus(String(error?.message || error || "Request failed"), "error");
    } finally {
        submitAuthBtn.disabled = false;
    }
}

function handleLogout() {
    clearStoredSession();
    renderSessionCard(null);
    renderTeacherResults([]);
    showStatus("Logged out.", "info");
}

loginTab.addEventListener("click", () => setAuthMode(AUTH_MODE_LOGIN));
registerTab.addEventListener("click", () => setAuthMode(AUTH_MODE_REGISTER));
authForm.addEventListener("submit", handleSubmit);
logoutBtn.addEventListener("click", handleLogout);
if (refreshTeacherResultsBtn) {
    refreshTeacherResultsBtn.addEventListener("click", loadTeacherResults);
}

setAuthMode(AUTH_MODE_LOGIN);
renderSessionCard(getStoredSession());
